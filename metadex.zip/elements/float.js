/* float.js - Floating images as a visualisation in Metadex Visualisations
    This is the display only tool of the float visualisation section of the metadex library
    the prefix for components in this file is MdxFV
    Relies on mdxVisualisation.js library -- MdxV -- for external functions
    Integrates with mdxSelection.js -- MdxS -- for selection of images
    Integrates with floatControl.js -- MdxVFc -- for control of float settings

    Author: Geoff Ebbs - giobono
    Developer: Ebono Institute
    Github: giobono/metadex
    License: CDDL-1.0
    Version: 0.5 <in Metadex v0.5>

    Originally developed as a prototype for research into MetaData interfaces as part of a Masters of Interactive Media - Griffith University 2018
*/


/* Conventions

    Global Variables are CamelCase with inital cap.
    local Variables are camelCase with no initial cap.
    local functions are camelCase with no initial cap
    functions are prefixed by the js library in which they belong (see introductory comments)

    So, for example, MdxFVisWidth is a locally global variable (used only in float routines), which is derived from the global (metadex wide) variable MdxVisWidth
*/


/* Assumptions and global variables 

    This version of the Metadex Visualisation library loads images into the DOM object as im1 -- im<NumImages>

*/

var numDspIms = 4, BImNo=0, fMar = 40, fYTop=4/8, fYBottom=7/8, visWidth, visHeight, bILeft, bITop; //number of images to display, number of background image, frame Margin, top and bottom of frame movement, leftEdge and topEdge of Background slice = local (global) variables to format layout (NumImages set in getcontent.php from database)
var swImArr = new Array(), ImNoArr = new Array();



function MdxFVInit() {
	endTimeouts();
	mousePos = [VisWidth/2, VisHeight/2]; // assume mouse centre screeen
	placeBImage(BImNo);
    // frame measurements are in pixels
    var fW = Math.floor((visWidth/numDspIms)-fMar);
    var fH = Math.floor((visHeight/numDspIms)-fMar);
    var thisY = new Array(); // position of frame
    var thisX = new Array();
    var fMX = new Array(); // movement of frame
    var fMY = new Array();
    var fOX = 0;
    var fOM = 0;
    var mP = mousePos;
    var iSlice = 1/numDspIms; // portion of image to show
    for (var i=0; i < numDspIms; i++ ) {
		if (!ImNoArr[i]) {
			swImArr[i] = new Image();
			// Get image from hidden section of document
			ImNoArr[i]=Math.round(Math.random()*NumImages)
			swImArr[i] = MdxVGetNewImage(ImNoArr[i]);			
		}
        // generate random y position close to horizon (visHeight/2);
        thisY[i] = Math.floor(visHeight/2+visHeight/(fMar/2)*(Math.random())); // set image near horizon
        fMX[i] = Math.random()*2-1; // set frame horizontal movement
        fMY[i] = Math.random()*2-1; // set frame vertical movement
        // Draw the first slice of the image Image measurements are fractions of 1 (to two decimal places)
        thisX[i] = Math.floor(i*visWidth/numDspIms)+(fMar/2); // the frame is positioned at the ith place along the camvas (cw*i/numDspIms)
        ctxVS.drawImage(swImArr[i], Math.floor(swImArr[i].width*(1-iSlice)), 0, Math.floor(swImArr[i].width*iSlice), swImArr[i].height, thisX[i], thisY[i], fW, fH);
    }
    moveIm(1-iSlice, thisX, thisY, fMX, fMY, fOX, fOM, mP); 
}

function setNewImage(thisIm) {
 // selected image from timeline at your service!
    var img = MdxVGetNewImage(thisIm);
    for (var i=0; i < numDspIms; i++ ) {
        swImArr[i] = img;
		ImNoArr[i] = thisIm;
    }
}


function placeBImage(imNo) {
 	var bImage = new Image();
	if(imNo > 0) {bImage.src = document.getElementById("im"+imNo).src.replace("-150x150","").replace("kayak4earth.com","lifejacket.ebono.com.au");} 
		else {bImage.src = "/wordpress/wp-content/themes/Kayak/images/AloneAtSea.jpg";}
	BImNo = imNo;
	visWidth = VisWidth;
	visHeight = VisHeight;                    
	if (bImage.width/bImage.height > visWidth/visHeight) {
		ctxVS.drawImage(bImage, (bImage.width - visWidth*bImage.height/visHeight)/2 , 0, visWidth*bImage.height/visHeight, bImage.height, 0, 0, visWidth, visHeight );	
	} else {
		ctxVS.drawImage(bImage, 0, (bImage.height - visHeight*bImage.width/visWidth)/2, bImage.width, visHeight*bImage.width/visWidth, 0, 0, visWidth, visHeight );
	}	
}


function moveIm(iX, fX, fY, fMX, fMY, fOX, fOM, mP) {
    // frame measurements are in pixels
	placeBImage(BImNo); // start by redrawing the background
    var fW = Math.floor((visWidth/numDspIms)-fMar/2);
    var fH = Math.floor((visHeight/numDspIms)-fMar/2);
    var mM; // mouse momentum
	mM = mousePos[0] - mP[0]; // establish mouse momentum
	if (Math.abs(mM) > visWidth/2 ) mM = 0; // just started OR swapped side of frame
	mP = mousePos;        
    if (mM == 0) { // if there is no mouse movement
        // set the frame offset to move all frames horizontally at random
        fOM += Math.random()-0.5;
        if (fOM > 2) fOM = 2; // constrain the momentum (pixels)
        if (fOM < -2) fOM = -2;
    } else {
        // set the frame offset with mouse momentum to move all frames horizontally in line with mouse movement
        fOM = (6*fOM + mM)/7;
    }
    fOX += fOM;
    // rotate arrays actually pops a new one in an opening gap - woould be more effective to constrain drift
    if (fOX > fW+fMar/2) { // time to rotate arrays
            fX.splice(0,0,fX[numDspIms-1]-visWidth);
            fX.splice(numDspIms,1);
            fY.splice(0,0,fY[numDspIms-1]);
            fY.splice(numDspIms,1);
            fMX.splice(0,0,fMX[numDspIms-1]);
            fMX.splice(numDspIms,1);
            fMY.splice(0,0,fMY[numDspIms-1]);
            fMY.splice(numDspIms,1);
            swImArr.splice(0,0,swImArr[numDspIms-1]);
            swImArr.splice(numDspIms,1);
            fOX -= fW+fMar/2;
    }; // END rotate array  
    if (fOX < -fW-fMar/2) { // time to rotate arrays
            fX.splice(numDspIms-1,0,fX[0]+visWidth);
            fX.splice(0,1);
            fY.splice(numDspIms-1,0,fY[0]);
            fY.splice(0,1);
            fMX.splice(numDspIms-1,0,fMX[0]);
            fMX.splice(0,1);
            fMY.splice(numDspIms-1,0,fMY[0]);
            fMY.splice(0,1);
            swImArr.splice(numDspIms-1,0,swImArr[0]);
            swImArr.splice(0,1);
            fOX += fW+fMar/2;
    }; // END rotate array
    

    // image measurements are in fractions of image
    var iMX = 0.007; // lateral speed of the image in the frame 
    var iSlice = 1/numDspIms; // get enough of the image to spread across the frames
    var iStart = iX-iMX; // move the image in the frame
    var iZ = 0; // no zoom
    var iZMax = 2; // full zoom is double size
    if (iStart < 0) {
        iStart += 1; // when the slice moves out of the image start again on the right edge
        if (Math.random() < 0.2) { // sometimes change the first image
			    ImNoArr[i]=Math.round(Math.random()*NumImages)
                swImArr[i] = MdxVGetNewImage(ImNoArr[i]); // randomise subject please!
            }
        }
    oldX=iStart; //store the value for next call
    for (var i=0; i < numDspIms; i++ ) {
        iStart = iX + i/numDspIms; // set the seam of the image depending on the frame number
        if (iStart > 1) {
            iStart -= 1; // when the image moves out of frame send it to the back or change it
            if (Math.random() < 1/(20*i)) { // make a change (i never 0 here)
                if (Math.random() > 0.9) {
         			ImNoArr[i]=Math.round(Math.random()*NumImages)
                    swImArr[i] = MdxVGetNewImage(ImNoArr[i]); // randomise subject please!
                } else {
                    swImArr[i] = swImArr[i-1]; // duplicate previous image 
                }
            }
        }; // END replace image at left 

        // adjust the horizontal speed of the frame using a random adjustment to the momentum
        fMX[i] += Math.random()-0.5;
        if (fMX[i] > 2) fMX[i] = 2; // constrain the momentum (pixels)
        if (fMX[i] < -2) fMX[i] = -2;
        fX[i] += fMX[i];        ImNoArr[i]=Math.round(Math.random()*NumImages)

        if (fX[i] > i*visWidth/(numDspIms)+ fMar/2) {fX[i] = i*visWidth/numDspIms + fMar/2}; // constrain the frame at right of its box
        if (fX[i] < i*visWidth/(numDspIms) - fMar/2) {fX[i] = i*visWidth/(numDspIms) - fMar/2}; // constrain the frame at left
        
        // adjust the vertical speed of the frame using a random adjustment to the momentum
        fMY[i] += Math.random()-0.5;
        if (fMY[i] > 2) fMY[i] = 2; // constrain the momentum (pixels)
        if (fMY[i] < -2) fMY[i] = -2;
        fY[i] += fMY[i];
        if (fY[i] > visHeight*fYBottom-fH ) { // constrain the frame
			fY[i] = visHeight*fYBottom-fH-fMar/8;
			fMY[i] = -1.5;
		} 
        if (fY[i] < visHeight*fYTop ) { // within fYTop and fYBottom
			fY[i] = visHeight*fYTop+fMar/8;
			fMY[i] = 1.5;
		} 
        // zoom the image based on last Mouse Y
        iZ = (mP[1]/visHeight-0.5); //0 (full frame) -> 1 (maz size)
        // Draw the image - adjusting the size of the native image
        putFrame(swImArr[i], Math.floor(swImArr[i].width*iStart), iZ/(2*iZMax)*(numDspIms-1)/(numDspIms*2), Math.floor(swImArr[i].width*iSlice*(2-iZ)/2), swImArr[i].height*(2-iZ)/(numDspIms - 1), fX[i]+fOX, fY[i], fW, fH);
        
        // NOW deal with images running off the screen
        if ((fOX > fMar) && (i == (numDspIms-1))) { // Frame is wandering off screen to right
            putFrame(swImArr[i], Math.floor(swImArr[i].width*iStart), iZ/(2*iZMax)*(numDspIms-1)/(numDspIms*2), Math.floor(swImArr[i].width*iSlice*(2-iZ)/2), swImArr[i].height*(2-iZ)/(numDspIms - 1), fX[i]+fOX-visWidth, fY[i], fW, fH);
          } 

        if (fOX < - fMar && i == 0) { // Frame is wandering off screen to left
            putFrame(swImArr[i], Math.floor(swImArr[i].width*iStart), iZ/(2*iZMax)*(numDspIms-1)/(numDspIms*2), Math.floor(swImArr[i].width*iSlice*(2-iZ)/2), swImArr[i].height*(2-iZ)/(numDspIms - 1), fX[i]+fOX+visWidth, fY[i], fW, fH);
          } // draw an additional version of left hand image at right edge

    } // for i < no images
	window.clearTimeout(MyTimeout);
	MyTimeout=setTimeout(function(){moveIm(oldX, fX, fY, fMX, fMY, fOX, fOM, mP)}, 70); 
}

function putFrame(img, sx, sy, px, py, fx, fy, dx, dy) {
    ctxVS.drawImage(img, sx, sy, px, py, fx, fy, dx, dy);   // Draw the left slice of the image
    ctxVS.drawImage(img, sx-img.width, sy, px, py, fx, fy, dx, dy); // draw an additional version of right hand image at left edge
}


