/* floatControl.js - Control the floating visualisation or Wordpress images in Metadex Visualisations
    This complements the display only tool (float.js) of the float visualisation section of the metadex library
    the prefix for components in this file is MdxVFC
    Relies on mdxVisualisation.js library -- MdxV -- for external functions Conventsions etc are explained there

    Author: Geoff Ebbs - giobono
    Developer: Ebono Institute
    Github: giobono/metadex
    License: CDDL-1.0
    Version: 0.6 <in Metadex v0.6>

    Originally developed as a prototype for research into MetaData interfaces as part of a Masters of Interactive Media - Griffith University 2018
*/

/* Overview of behaviour
    1 Draw background image
    2 Based on mousemode_mode and MdxFVmode determine colours and settingV
    3 Draw panel over box

    In step 2
    for mouse mode reveal
        on format identify zone and highlight box
        on FBIdentify move dBack to new position mP[x]
        on FFIdentify move frame to new position mP[y]
    
    for mouse mode identify
        switch mode to control mouse reveal behavour
        highlight edge of box to be moved
    
    For moouse mode select
        on format switch mode to pass control to mxC (selection) routines
        on FBIdentify store position mP[x] as BILeft
        on FFIdentify store position mP[x] as FITop
*/


/* Global variables
the Background Image No <MdxVBImNo>, and the top-left corner of its active portion <MdxVBIPos[]> are global variables available to all visualisations (declared in metadex.js)
    - the Metadex convention of passing measurements in pixels is used for these variabes

the Frame Image <FloatImNo>, Frame Position <FloatFDTop> and <FloatFDBottom> are global variables relevant only to the float routines.
    - The convention of float routines to store dimensions as percentages is used for these variables.

Colours of the panel selections are local to the formatFloat routine

This routine responds to MxMouseMode <mode - at the moment> and resets <MxVCMode> to determine the behaviour of the canvas in response to the mouse.

The current convention is that each change results in a return to the naked visualisation so that the results can be displayed. Local variables have been used to enable the inScreen emulation of the display if that is deemed desirable. It was not considered necessary for the development of the Minimum Viable Product.
*/
var FloatImNo, FloatFDTop, FloatFDBottom;

function drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor) {
	drawFullImage(bImage);
	drawBox(bDLeft,bDTop,visWidth,visHeight,bDColor);
	drawBox(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight,bIColor);
	drawBox(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight,fDColor);
}

function drawBox(sX,sY,bW,bH,colour) {
	ctxVS.beginPath();
    ctxVS.lineWidth = Linewidth;
    ctxVS.strokeStyle=colour;
    ctxVS.moveTo(sX,sY);
    ctxVS.lineTo(sX+bW, sY);
    ctxVS.stroke();
    ctxVS.lineTo(sX+bW, sY+bH);
    ctxVS.stroke();
    ctxVS.lineTo(sX, sY+bH);
    ctxVS.stroke();
    ctxVS.lineTo(sX, sY);
    ctxVS.stroke();
}

function formatFloat(mP, mode) { // called from Canvas via revealVis in storylines.js, mouse pointer and mouse mode.
	var bDTop, bDLeft, bDHeight, bDWidth, bISCropped, bDColor='#6666ee', fDTop, fDBottom, fDColor='#cccc66', bIColor='#ee6666', sZone='offscreen';
	endTimeouts(); // stop any other routines writing to the canvas
	if (mode == null) mode='reveal'; // set default mousemode
    if (MdxVCMode == null || MdxVCMode == 'naked') MdxVCMode='format'; //set default behaviour 
    
    /* Draw background image and calculate sizings for the rest of the routines
        Set up the dimensions based on the background image (the number of dimensions makes this function central and, so, large - there are so many)
        bI<property> and fI<property> are properties of the image
        bD<property> and fD<property> are properties of the display area
        */
 	var bImage = new Image();
	if(MdxVBImNo > 0) {bImage.src = document.getElementById("im"+MdxVBImNo).src.replace("-150x150","");} 
		else {bImage.src = "/wordpress/wp-content/plugins/metadex/images/AloneAtSea.jpg";} // a default image is available	
    bISCropped = bImage.width/bImage.height > VisWidth/VisHeight; //calculations AND behaviours differ for tall images
	if (bISCropped) { // sides are cropped
		bDWidth = VisWidth;
		bDHeight = bImage.height * VisWidth / bImage.width; // displayed height = real height * screen width / real width
		visWidth = bDHeight * VisWidth / VisHeight; // displayed height * screen width / screen height 
		visHeight = bDHeight; 
		bILeft = (VisWidth-visWidth)/2;
    	bITop = 0;
	} else { // top and bottom is cropped
		bDHeight = VisHeight;
		bDWidth = bImage.height * VisHeight/VisWidth; // displayed width = real width * screen height / real height
		visWidth = bDWidth; 
		visHeight = bDWidth * VisHeight / VisWidth;
		bILeft=0; // set global variables to crop background image
		bITop = (VisHeight-visHeight)/2;
    }
    if (MdxVBIPos[0] == null || MdxVBIPos[0] == 0) {bDLeft = (VisWidth-visWidth)/2;} else {bDLeft=MdxVBIPos[0];} // set left edge based on global variable 
    if (MdxVBIPos[1] == null || MdxVBIPos[1] == 0) {bDTop = (VisHeight-visHeight)/2;} else {bDTop=MdxVBIPos[1];} // set right edge based on global variable

    // start working with the mouse position
    
    // determine what zone the mouse is in        
	if (mP[0] > bDLeft-bILeft && mP[0] < bDLeft-bILeft+bDWidth && mP[1] > bDTop-bITop && mP[1] < bDTop-bITop+bDHeight) { // mouse inside background image
		if (mP[0] > bDLeft && mP[0] < bDLeft+visWidth && mP[1] > bDTop && mP[1] < bDTop+bDHeight) { //mouse inside displayed bdImage
			if (mP[0] > bDLeft && mP[0] < bDLeft+visWidth && mP[1] > bDTop+fYTop*visHeight && mP[1] < bDTop+fYBottom*visHeight) { // mouse inside frame zone
				if (mP[0] > bDLeft && mP[0] < bDLeft+visWidth && mP[1] > bDTop+fYTop*visHeight && mP[1] < bDTop+fYTop*visHeight+Linewidth) { // mouse in frame top line
					sZone = 'frameline';
				} else {sZone = 'frames';}
			} else {sZone = 'dBack';} 
		} else {sZone = 'back';}
	} else {
        sZone = 'offScreen';
        if (mode=='select') { // handle off screen clicks first
            // go back to format mode on an offscreen click
            MdxVCMode = 'format'; //clicking off screen returns to format mode
            timeline(0,"white");
            drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor);
        }
    }
        
    console.log(bDLeft,bILeft,sZone);
    switch (mode) { // identify the mouse mode
        case 'reveal':
            switch (MdxVCMode) {
                case 'format':
                    // and go back to format mode on an offscreen click

                    // draw the basics
                    drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor);
                    if (mode == 'reveal') { // coming from mouseover. The mouse highlights the format 
                        switch (sZone) {
                            case 'back':
                                drawBox(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight,"red");
                                timeline(MdxVBImNo,bIColor);
                                break;
                            case 'dBack':
                                drawBox(bDLeft,bDTop,visWidth,visHeight,"blue");
                                timeline(0,"white");
                                break;
                            case 'frames':
                                drawBox(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight,"yellow");
                                timeline(ImNoArr[1],fDColor);
                                break;
                            default:
                                break;
                        }			
                    }
                break;
                case 'FBIdentify':
                    drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor);
                    drawBox(mP[0],bDTop,visWidth,visHeight,bDColor);
                    ctxVS.beginPath();
                    ctxVS.lineWidth = Linewidth;
                    ctxVS.strokeStyle="blue";
                    ctxVS.moveTo(bDLeft,bDTop);
                    ctxVS.lineTo(bDLeft,bDTop+visHeight);
                    ctxVS.stroke();
                    timeline(MdxVBImNo,"blue");
                    break;
                case 'FFidentify':
                    break;
                default: 
                    break;
            }
            break;
        case 'identify':
            switch (sZone) {
                case 'dBack':
                    MdxVCMode = 'FBIdentify'
                    if (bISCropped) {
                        drawBox(mP[0],bDTop,visWidth,visHeight,bDColor);
                    } else {
                        drawBox(bDLeft,mP[1],visWidth,visHeight,bDColor);
                    }
                    ctxVS.beginPath();
                    ctxVS.lineWidth = Linewidth;
                    ctxVS.strokeStyle="blue";
                    ctxVS.moveTo(bDLeft,bDTop);
                    ctxVS.lineTo(bDLeft,bDTop+visHeight);
                    ctxVS.stroke();
                    timeline(MdxVBImNo,"blue");
                    break;
                case 'frames':
                    MdxVCMode = 'FFIdentify'
                    //fYTop = (mP[1]-bITop)/visHeight;
                    drawBox(bDLeft,mP[1],visWidth,(fYBottom-fYTop)*visHeight,"yellow");
                    ctxVS.fillStyle='rgba(200,200,100,.5)';
                    ctxVS.fillRect(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight);
                    timeline(ImNoArr[1],'yellow');
                    break;
                default:
                    break;
            }
            break;
        case 'select':
            switch (MdxVCMode) {
                case 'format':    
                    switch (sZone) {
                        case 'back':
                            drawBox(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight,"red");
                            ctxVS.fillStyle='rgba(200,100,100,.5)';
                            ctxVS.fillRect(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight);
                            timeline(MdxVBImNo,"red");
                            MdxVCMode = 'bISelect';
                            break;
                        case 'dBack':
                            drawBox(bDLeft,bDTop,visWidth,visHeight,bDColor);
                            ctxVS.beginPath();
                            ctxVS.lineWidth = Linewidth;
                            ctxVS.strokeStyle="blue";
                            ctxVS.moveTo(bDLeft,bDTop);
                            ctxVS.lineTo(bDLeft,bDTop+visHeight);
                            ctxVS.stroke();
                            timeline(0,"white");
                            MdxVCMode = 'bIIdentify';
                            break;
                        case 'frames':
                            drawBox(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight,"yellow");
                            ctxVS.fillStyle='rgba(200,200,100,.5)';
                            ctxVS.fillRect(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight);
                            timeline(ImNoArr[1],'yellow');
                            MdxVCMode = 'fISelect';
                            break;
                        default:
                            // go back to format mode on an offscreen click
                            console.log("clicking out in open space .... HELP!!! Send nudes.");
                            MdxVCMode = 'format'; //clicking off screen returns to format mode
                            timeline(0,"white");
                            drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor);
                            break;                
                    }
                    break;
                case 'FBIdentify':
                    if (bISCropped) {
                        bDLeft=mP[0];
                        bDTop=0;
                    } else{
                        bDLeft=0;
                        bDTop=mP[1];
                    }
                    MdxVBIPos = [bDLeft, bDTop]; //Set global variable
                    MdxVCMode='naked';
                    MdxVFInit();
                    break;
            }
        }
    }