<?php 
    /* File returns text from wordpress for storylines application
    is sent the relevant parameter $_GET['p'] and returns the information on the parameter and related topics from wordpress*/
    // Database Variables
?>
<html>
    <head><link rel="stylesheet" type="text/css" href="storylines.css"></head>
    <body>
<?php
include "site_config.php";
function getStories($thisp) {
    $newContent = ""; 
    // set local instance of database variables because thats the way PHP works
    $server = "mysql7.quadrahosting.com.au";
    $user = 'ebono_wpdba';
    $pass = 'f10Renza';
    $db = 'ebono_gen_wp';
    // Connect to Database
    $conn = new mysqli($server, $user, $pass, $db);

        /* Start by searching for the parameter itself
    First search is for a description of the parameter */
    $sql = "SELECT name, description FROM  `wp_term_taxonomy` tt LEFT JOIN wp_terms t ON tt.term_id = t.term_id WHERE tt.term_id =".$thisp;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $paraName = $row["name"]; 
            $paraDesc = $row["description"]; 
            if (strlen($paraName)>0) {
                $newContent = $newContent . "<h2>".$paraName."</h2>\n<p><span style=\"color: blue;\">defn:</span>" . substr(preg_replace('/\[.*?\]/', '', strip_tags($paraDesc)),0,128) . "<a href=\"\"> ...</a></p>\n";
            } 
        }
    }
    /* Now search for articles about the parameter (counting the number of categories the article is in to exlude more specific ones) */
    $sql = "SELECT id, post_title, post_content, (select count(*) from wp_term_relationships r where r.object_id=p.id) as category_counter FROM  `wp_posts` p where post_type=\"post\" and id in (select object_id from wp_term_relationships where term_taxonomy_id = ".$thisp.") order by category_counter limit 0 , 4";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            if ($row["category_counter"] == 1) {
                $paraDesc = $row["post_title"]; 
                if (strlen($paraDesc)>0) {
                $newContent = $newContent . "<h3><a href=\"".$site."?p=".$row["id"]."\" target=\"Pathmap\">".$paraDesc."</a></h3>";
                } 
                $paraDesc = $row["post_content"]; 
                if (strlen($paraDesc)>0) {
                    $newContent = $newContent . "<p>".substr(preg_replace('/\[.*?\]/', '', strip_tags($paraDesc)),0,128)."<a href=\"".$site."?p=".$row["id"]."\" target=\"Pathmap\"> ...</a></p>";
                } 
            } /* the results have the parameter as the only categorsy */
        } /* While we are going through results */
    } /* we have results for posts */ 
    return $newContent;
}
    $p = $_GET['p'];
    $nContent = "<div id='item_0' class='black'>".getStories($p)."</div>";
    $nContent = $nContent."<h3>Finished main stories</h3>";

    // Now select the topics related to this one
    $sql2 = "select tt.term_taxonomy_id as t_id, name, count(*) as cnt"; 
    $sql2 .= "     from wp_term_relationships tr, wp_term_taxonomy tt, wp_terms";
    /* prepare posts and categories with smallest term_id per post */
    $sql2 .= "    where tr.term_taxonomy_id = tt.term_taxonomy_id ";
    $sql2 .= "		    and   tt.taxonomy in ('post_tag', 'category')";
    $sql2 .= "    and   tt.term_id          = wp_terms.term_id";
    $sql2 .= "    and   tr.object_id in ";
    $sql2 .= "	(select distinct tr1.object_id  ";
    $sql2 .= "    	from wp_term_relationships tr1";
    $sql2 .= "		where tr1.term_taxonomy_id = ".$p.")";
    $sql2 .= "      and tt.term_id != ".$p;
    $sql2 .= "  group by tt.term_taxonomy_id";
    $sql2 .= "  order by cnt desc";
    $sql2 .= "	limit 6";
    // echo $sql2;
    $result2 = $conn->query($sql2);
    $i = 1;

    if ($result2->num_rows > 0) {
        while($row2 = $result2->fetch_assoc()) {
            // echo "<p>Made it here ".$i." times.</p>/n";
            $nContent = $nContent . "<div id=item_" . $i . " class='grey'>" . getStories($row2["t_id"]) . "</div>";
            // $nContent = $nContent . $row2["name"]."^".$row2["t_id"]."^".$row2["cnt"]."|";
            $i = $i +1;
        }                      
    }

    $conn->close();
    echo $nContent;
?>    
    </body>
</html>
