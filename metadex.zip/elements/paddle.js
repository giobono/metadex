var numDspIms = 4, BImNo=0, fMar = 40, fYTop=4/8, fYBottom=7/8, visWidth, visHeight, bILeft, bITop; //number of images to display, number of background image, frame Margin, top and bottom of frame movement, leftEdge and topEdge of Background slice = local (global) variables to format layout (NumImages set in getcontent.php from database)
var swImArr = new Array(), ImNoArr = new Array();

function init() {
	endTimeouts();
	mousePos = [VisWidth/2, VisHeight/2]; // assume mouse centre screeen
	placeBImage(BImNo);
    // frame measurements are in pixels
    var fW = Math.floor((visWidth/numDspIms)-fMar);
    var fH = Math.floor((visHeight/numDspIms)-fMar);
    var thisY = new Array(); // position of frame
    var thisX = new Array();
    var fMX = new Array(); // movement of frame
    var fMY = new Array();
    var fOX = 0;
    var fOM = 0;
    var mP = mousePos;
    var iSlice = 1/numDspIms; // portion of image to show
    for (var i=0; i < numDspIms; i++ ) {
		if (!ImNoArr[i]) {
			swImArr[i] = new Image();
			// Get image from hidden section of document
			ImNoArr[i]=Math.round(Math.random()*NumImages)
			swImArr[i] = getNewImage(ImNoArr[i]);			
		}
        // generate random y position close to horizon (visHeight/2);
        thisY[i] = Math.floor(visHeight/2+visHeight/(fMar/2)*(Math.random())); // set image near horizon
        fMX[i] = Math.random()*2-1; // set frame horizontal movement
        fMY[i] = Math.random()*2-1; // set frame vertical movement
        // Draw the first slice of the image Image measurements are fractions of 1 (to two decimal places)
        thisX[i] = Math.floor(i*visWidth/numDspIms)+(fMar/2); // the frame is positioned at the ith place along the camvas (cw*i/numDspIms)
        ctxVS.drawImage(swImArr[i], Math.floor(swImArr[i].width*(1-iSlice)), 0, Math.floor(swImArr[i].width*iSlice), swImArr[i].height, thisX[i], thisY[i], fW, fH);
    }
    moveIm(1-iSlice, thisX, thisY, fMX, fMY, fOX, fOM, mP); 
}

function setNewImage(thisIm) {
 // selected image from timeline at your service!
    var img = getNewImage(thisIm);
    for (var i=0; i < numDspIms; i++ ) {
        swImArr[i] = img;
		ImNoArr[i] = thisIm;
    }
}

function getNewImage(imNo) {
 // random image at your service!
    var imgName = "im" + imNo, img = new Image();
    img.src = document.getElementById(imgName).src.replace("-150x150","").replace("kayak4earth.com","lifejacket.ebono.com.au");
    return img;
}

function placeBImage(imNo) {
 	var bImage = new Image();
	if(imNo > 0) {bImage.src = document.getElementById("im"+imNo).src.replace("-150x150","").replace("kayak4earth.com","lifejacket.ebono.com.au");} 
		else {bImage.src = "/wordpress/wp-content/themes/Kayak/images/AloneAtSea.jpg";}
	BImNo = imNo;
	visWidth = VisWidth;
	visHeight = VisHeight;                    
	if (bImage.width/bImage.height > visWidth/visHeight) {
		ctxVS.drawImage(bImage, (bImage.width - visWidth*bImage.height/visHeight)/2 , 0, visWidth*bImage.height/visHeight, bImage.height, 0, 0, visWidth, visHeight );	
	} else {
		ctxVS.drawImage(bImage, 0, (bImage.height - visHeight*bImage.width/visWidth)/2, bImage.width, visHeight*bImage.width/visWidth, 0, 0, visWidth, visHeight );
	}	
}

function drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor) {
	drawFullImage(bImage);
	drawBox(bDLeft,bDTop,visWidth,visHeight,bDColor);
	drawBox(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight,bIColor);
	drawBox(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight,fDColor);
}

function formatPaddles(mP, mode) { // called from Canvas via prepVis in storylines.js, mouse pointer and mouse mode.
	var bDTop, bDLeft, bDHeight, bDWidth, bDColor='#6666ee', fDTop, fDBottom, fDColor='#cccc66', bIColor='#ee6666', sZone='offscreen';
 	var bImage = new Image();
	if (!mode) mode='prep';
    // Set up the dimensions based on the background image (the number of dimensions makes this function central and, so, large - there are so many)
    
	if(BImNo > 0) {bImage.src = document.getElementById("im"+BImNo).src.replace("-150x150","").replace("kayak4earth.com","lifejacket.ebono.com.au");} 
		else {bImage.src = "/word(bImage.width/bImage.height > visWidth/visHeight) {press/wp-content/themes/Kayak/images/AloneAtSea.jpg";}	
	if (bImage.width/bImage.height > VisWidth/VisHeight) { // sides are cropped
		bDWidth = VisWidth;
		bDHeight = bImage.height * VisWidth / bImage.width; // displayed height = real height * screen width / real width
		visWidth = bDHeight * VisWidth / VisHeight; // displayed height * screen width / screen height 
		visHeight = bDHeight; 
		bILeft = (VisWidth-visWidth)/2; // set global variables to crop background image
		bITop = 0;
	} else { // top and bottom is cropped
		bDHeight = VisHeight;
		bDWidth = bImage.height * VisHeight/VisWidth; // displayed width = real width * screen height / real height
		visWidth = bDWidth; 
		visHeight = bDWidth * VisHeight / VisWidth;
		bILeft=0; // set global variables to crop background image
		bITop = (VisHeight-visHeight)/2;
	}
	bDLeft = (VisWidth-visWidth)/2; 
	bDTop = (VisHeight-visHeight)/2;
        
	endTimeouts(); // stop any other routines writing to the canvas
    
    
    // determine what zone the mouse is in    
    
	if (mP[0] > bDLeft-bILeft && mP[0] < bDLeft-bILeft+bDWidth && mP[1] > bDTop-bITop && mP[1] < bDTop-bITop+bDHeight) { // mouse inside background image
		if (mP[0] > bDLeft && mP[0] < bDLeft+visWidth && mP[1] > bDTop && mP[1] < bDTop+bDHeight) { //mouse inside displayed bdImage
			if (mP[0] > bDLeft && mP[0] < bDLeft+visWidth && mP[1] > bDTop+fYTop*visHeight && mP[1] < bDTop+fYBottom*visHeight) { // mouse inside frame zone
				if (mP[0] > bDLeft && mP[0] < bDLeft+visWidth && mP[1] > bDTop+fYTop*visHeight && mP[1] < bDTop+fYTop*visHeight+Linewidth) { // mouse in frame top line
					sZone = 'frameline';
				} else {sZone = 'frames';}
			} else {sZone = 'dBack';} 
		} else {sZone = 'back';}
	} else sZone = 'offScreen';

    // and go back to format mode on an offscreen click
    
    if (sZone == 'offScreen' && mode == 'select') { // That's all folks 
        VisMode = 'format'; 
        timeline(0,"white");
        drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor);        

    } else { // handle the mouse action
        
        // draw the basics
        drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor);
        if (mode == 'prep') { // coming from mouseover. The mouse highlights the format 
            switch (sZone) {
                case 'back':
                    drawBox(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight,"red");
                    timeline(BImNo,bIColor);
                    break;
                case 'dBack':
                    drawBox(bDLeft,bDTop,visWidth,visHeight,"blue");
                    timeline(0,"white");
                    break;
                case 'frames':
                    drawBox(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight,"yellow");
                    timeline(ImNoArr[1],fDColor);
                    break;
                default:
                    break;
            }			
        }
        if (mode == 'slide') { // coming from mouse down - switch VisMode so that selected format moves with mouse
            switch (sZone) {
                case 'dBack':
                    VisMode = ''
                    drawBox(mP[0],bDTop,visWidth,visHeight,bDColor);
                    ctxVS.beginPath();
                    ctxVS.lineWidth = Linewidth;
                    ctxVS.strokeStyle="blue";
                    ctxVS.moveTo(bDLeft,bDTop);
                    ctxVS.lineTo(bDLeft,bDTop+visHeight);
                    ctxVS.stroke();
                    timeline(0,"white");
                    break;
                case 'frames':
                    //fYTop = (mP[1]-bITop)/visHeight;
                    drawBox(bDLeft,mP[1],visWidth,(fYBottom-fYTop)*visHeight,"yellow");
                    ctxVS.fillStyle='rgba(200,200,100,.5)';
                    ctxVS.fillRect(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight);
                    timeline(ImNoArr[1],'yellow');
                    break;
                default:
                    break;
            }
        } 
        if (mode == 'select') { // coming from mouse up (click)
            if (VisMode == 'format') {
                switch (sZone) {
                    case 'back':
                        drawBox(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight,"red");
                        ctxVS.fillStyle='rgba(200,100,100,.5)';
                        ctxVS.fillRect(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight);
                        timeline(BImNo,"red");
                        VisMode = 'bISelect';
                        break;
                    case 'dBack':
                        drawBox(bDLeft,bDTop,visWidth,visHeight,bDColor);
                        ctxVS.beginPath();
                        ctxVS.lineWidth = Linewidth;
                        ctxVS.strokeStyle="blue";
                        ctxVS.moveTo(bDLeft,bDTop);
                        ctxVS.lineTo(bDLeft,bDTop+visHeight);
                        ctxVS.stroke();
                        timeline(0,"white");
                        VisMode = 'bISlide';
                        break;
                    case 'frames':
                        drawBox(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight,"yellow");
                        ctxVS.fillStyle='rgba(200,200,100,.5)';
                        ctxVS.fillRect(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight);
                        timeline(ImNoArr[1],'yellow');
                        VisMode = 'fISelect';
                        break;
                    default:
                        break;
                }			
            } else {
                    VisMode = 'format'; //clicking off screen returns to format mode
                    timeline(0,"white");
                    drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor);

            }
        }
    }

}

function drawBox(sX,sY,bW,bH,colour) {
	ctxVS.beginPath();
    ctxVS.lineWidth = Linewidth;
    ctxVS.strokeStyle=colour;
    ctxVS.moveTo(sX,sY);
    ctxVS.lineTo(sX+bW, sY);
    ctxVS.stroke();
    ctxVS.lineTo(sX+bW, sY+bH);
    ctxVS.stroke();
    ctxVS.lineTo(sX, sY+bH);
    ctxVS.stroke();
    ctxVS.lineTo(sX, sY);
    ctxVS.stroke();
}
function moveIm(iX, fX, fY, fMX, fMY, fOX, fOM, mP) {
    // frame measurements are in pixels
	placeBImage(BImNo); // start by redrawing the background
    var fW = Math.floor((visWidth/numDspIms)-fMar/2);
    var fH = Math.floor((visHeight/numDspIms)-fMar/2);
    var mM; // mouse momentum
	mM = mousePos[0] - mP[0]; // establish mouse momentum
	if (Math.abs(mM) > visWidth/2 ) mM = 0; // just started OR swapped side of frame
	mP = mousePos;        
    if (mM == 0) { // if there is no mouse movement
        // set the frame offset to move all frames horizontally at random
        fOM += Math.random()-0.5;
        if (fOM > 2) fOM = 2; // constrain the momentum (pixels)
        if (fOM < -2) fOM = -2;
    } else {
        // set the frame offset with mouse momentum to move all frames horizontally in line with mouse movement
        fOM = (6*fOM + mM)/7;
    }
    fOX += fOM;
    // rotate arrays actually pops a new one in an opening gap - woould be more effective to constrain drift
    if (fOX > fW+fMar/2) { // time to rotate arrays
            fX.splice(0,0,fX[numDspIms-1]-visWidth);
            fX.splice(numDspIms,1);
            fY.splice(0,0,fY[numDspIms-1]);
            fY.splice(numDspIms,1);
            fMX.splice(0,0,fMX[numDspIms-1]);
            fMX.splice(numDspIms,1);
            fMY.splice(0,0,fMY[numDspIms-1]);
            fMY.splice(numDspIms,1);
            swImArr.splice(0,0,swImArr[numDspIms-1]);
            swImArr.splice(numDspIms,1);
            fOX -= fW+fMar/2;
    }; // END rotate array  
    if (fOX < -fW-fMar/2) { // time to rotate arrays
            fX.splice(numDspIms-1,0,fX[0]+visWidth);
            fX.splice(0,1);
            fY.splice(numDspIms-1,0,fY[0]);
            fY.splice(0,1);
            fMX.splice(numDspIms-1,0,fMX[0]);
            fMX.splice(0,1);
            fMY.splice(numDspIms-1,0,fMY[0]);
            fMY.splice(0,1);
            swImArr.splice(numDspIms-1,0,swImArr[0]);
            swImArr.splice(0,1);
            fOX += fW+fMar/2;
    }; // END rotate array
    

    // image measurements are in fractions of image
    var iMX = 0.007; // lateral speed of the image in the frame 
    var iSlice = 1/numDspIms; // get enough of the image to spread across the frames
    var iStart = iX-iMX; // move the image in the frame
    var iZ = 0; // no zoom
    var iZMax = 2; // full zoom is double size
    if (iStart < 0) {
        iStart += 1; // when the slice moves out of the image start again on the right edge
        if (Math.random() < 0.2) { // sometimes change the first image
			    ImNoArr[i]=Math.round(Math.random()*NumImages)
                swImArr[i] = getNewImage(ImNoArr[i]); // randomise subject please!
            }
        }
    oldX=iStart; //store the value for next call
    for (var i=0; i < numDspIms; i++ ) {
        iStart = iX + i/numDspIms; // set the seam of the image depending on the frame number
        if (iStart > 1) {
            iStart -= 1; // when the image moves out of frame send it to the back or change it
            if (Math.random() < 1/(20*i)) { // make a change (i never 0 here)
                if (Math.random() > 0.9) {
         			ImNoArr[i]=Math.round(Math.random()*NumImages)
                    swImArr[i] = getNewImage(ImNoArr[i]); // randomise subject please!
                } else {
                    swImArr[i] = swImArr[i-1]; // duplicate previous image 
                }
            }
        }; // END replace image at left 

        // adjust the horizontal speed of the frame using a random adjustment to the momentum
        fMX[i] += Math.random()-0.5;
        if (fMX[i] > 2) fMX[i] = 2; // constrain the momentum (pixels)
        if (fMX[i] < -2) fMX[i] = -2;
        fX[i] += fMX[i];        ImNoArr[i]=Math.round(Math.random()*NumImages)

        if (fX[i] > i*visWidth/(numDspIms)+ fMar/2) {fX[i] = i*visWidth/numDspIms + fMar/2}; // constrain the frame at right of its box
        if (fX[i] < i*visWidth/(numDspIms) - fMar/2) {fX[i] = i*visWidth/(numDspIms) - fMar/2}; // constrain the frame at left
        
        // adjust the vertical speed of the frame using a random adjustment to the momentum
        fMY[i] += Math.random()-0.5;
        if (fMY[i] > 2) fMY[i] = 2; // constrain the momentum (pixels)
        if (fMY[i] < -2) fMY[i] = -2;
        fY[i] += fMY[i];
        if (fY[i] > visHeight*fYBottom-fH ) { // constrain the frame
			fY[i] = visHeight*fYBottom-fH-fMar/8;
			fMY[i] = -1.5;
		} 
        if (fY[i] < visHeight*fYTop ) { // within fYTop and fYBottom
			fY[i] = visHeight*fYTop+fMar/8;
			fMY[i] = 1.5;
		} 
        // zoom the image based on last Mouse Y
        iZ = (mP[1]/visHeight-0.5); //0 (full frame) -> 1 (maz size)
        // Draw the image - adjusting the size of the native image
        putFrame(swImArr[i], Math.floor(swImArr[i].width*iStart), iZ/(2*iZMax)*(numDspIms-1)/(numDspIms*2), Math.floor(swImArr[i].width*iSlice*(2-iZ)/2), swImArr[i].height*(2-iZ)/(numDspIms - 1), fX[i]+fOX, fY[i], fW, fH);
        
        // NOW deal with images running off the screen
        if ((fOX > fMar) && (i == (numDspIms-1))) { // Frame is wandering off screen to right
            putFrame(swImArr[i], Math.floor(swImArr[i].width*iStart), iZ/(2*iZMax)*(numDspIms-1)/(numDspIms*2), Math.floor(swImArr[i].width*iSlice*(2-iZ)/2), swImArr[i].height*(2-iZ)/(numDspIms - 1), fX[i]+fOX-visWidth, fY[i], fW, fH);
          } 

        if (fOX < - fMar && i == 0) { // Frame is wandering off screen to left
            putFrame(swImArr[i], Math.floor(swImArr[i].width*iStart), iZ/(2*iZMax)*(numDspIms-1)/(numDspIms*2), Math.floor(swImArr[i].width*iSlice*(2-iZ)/2), swImArr[i].height*(2-iZ)/(numDspIms - 1), fX[i]+fOX+visWidth, fY[i], fW, fH);
          } // draw an additional version of left hand image at right edge

    } // for i < no images
	window.clearTimeout(MyTimeout);
	MyTimeout=setTimeout(function(){moveIm(oldX, fX, fY, fMX, fMY, fOX, fOM, mP)}, 70); 
}

function putFrame(img, sx, sy, px, py, fx, fy, dx, dy) {
    ctxVS.drawImage(img, sx, sy, px, py, fx, fy, dx, dy);   // Draw the left slice of the image
    ctxVS.drawImage(img, sx-img.width, sy, px, py, fx, fy, dx, dy); // draw an additional version of right hand image at left edge
}

