<?php
    // Site settings
    $mx_site = "http://thegenerator.com.au";
    $mx_server = "mysql7.quadrahosting.com.au";
    $mx_user = 'ebono_wpdba';
    $mx_pass = 'f10Renza';
    $mx_db = 'ebono_gen_wp';
    // Connect to Database
    $mx_conn = new mysqli($mx_server, $mx_user, $mx_pass, $mx_db);

    // Check connection
    if (!$mx_conn) {
        die("Connection failed: " . mysqli_connect_error());
    } else { echo "<!-- Connected -->";}
?>
