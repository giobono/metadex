// Storylines.js - written by Geoff Ebbs: Ebono Institute for Masters Interactive Media: Griffith University 2018
var VisPanel, VisMode='naked', TimeMachine, TMState, ActivePanel, Linewidth=10; // set Global interface variables - numImages set from database in elements/setContent.php

// Routines for managing timeline panel

function detectTMItem(mpt) {
    // return integer between 0 and numImages to determine Time Machine setting
    var thisIm = Math.floor(mpt[1]*NumImages/(VisHeight));
    if (thisIm > NumImages) {thisIm = NumImages;}
    if (thisIm < 1) {thisIm = 1;}
    return thisIm;
}


function prepMdx(mpt) { // shows metadex control
	
}
function readMdx(mpt) { // selects metadex control 
	
}
function writeMdx(mpt) { // confirms metadex control
	
}
function selectMode(thisMode) { //selects Displaymode
	DisplayMode = thisMode;
	switch (DisplayMode) {
		case 'matrix':
			VisMode = 'naked';
			endTimeouts();
			placeImages();
			break;
		case 'autoplay':
			endTimeouts();
			if (ImNo < 1) {
			  var mousePos = [1,1];
        	  ImNo = 1;
			}
			incIm();
    		break;
		case 'paddle':
			endTimeouts();
			VisMode = 'naked';
			BImNo = ImNo;
            init();
    		break;
		default:
			break;
	}
	setVCtrl(DisplayMode);
}

// functions called by display area control commands based on DisplayMode
// Set up local controls for this mode
function setVCtrl(thisMode) {
	switch (DisplayMode) {
		case 'autoplay':
			document.getElementById("vC1").innerHTML = "<img src='" + document.getElementById("leftArrow").src +  "' height='" + CtrlHeight + "' width='" + CtrlHeight + "' alt='Backward'>";
			document.getElementById("vC2").innerHTML = "<img src='" + document.getElementById("pauseCtrl").src +  "' height='" + CtrlHeight + "' width='" + CtrlHeight + "' alt='Pause'>";
			document.getElementById("vC3").innerHTML = "<img src='" + document.getElementById("rightArrow").src + "' height='" + CtrlHeight + "' width='" + CtrlHeight + "' alt='Forward'>";
			document.getElementById("vC4").innerHTML = "<img src='" + document.getElementById("speedCtrl").src +  "' height='" + CtrlHeight + "' width='" + CtrlHeight + "' alt='Speed Up'>";
    		break;
		case 'paddle':
			document.getElementById("vC1").innerHTML = "<img src='" + document.getElementById("moveImage").src +  "' height='" + CtrlHeight + "' width='" + CtrlHeight + "' alt='MoveImages'>";
			document.getElementById("vC2").innerHTML = "<img src='" + document.getElementById("formatImage").src +  "' height='" + CtrlHeight + "' width='" + CtrlHeight + "' alt='Format Images'>";
			document.getElementById("vC3").innerHTML = "";
			document.getElementById("vC4").innerHTML = "";
    		break;
		default:
			document.getElementById("vC1").innerHTML = "";
			document.getElementById("vC2").innerHTML = "";
			document.getElementById("vC3").innerHTML = "";
			document.getElementById("vC4").innerHTML = "";
			break;
	}	
}

function selectCtrl(thisCtrl) { //selects Displaymode
	switch (DisplayMode) {
		case 'autoplay':
			switch (thisCtrl) {
				case 1:
					ImNo -= 1;
            		fullImage(ImNo);
					break;
				case 2:
					DispDelay = 100000;
					break;
				case 3:
					if (DispDelay == 100000) DispDelay = 1000;
					ImNo += 1;
            		fullImage(ImNo);
					break;
				case 4:
					DispDelay = DispDelay/2;
					break;
				default:
					break;
			};
			break;
   		case 'paddle':
			switch (thisCtrl) {
				case 1:
					VisMode = 'naked';
					BImNo = ImNo;
					init();
					break;
				case 2:
					VisMode = 'format';
					formatPaddles(mousePos,'prep');
					break;
				default:
					break;
			}
			break;
		default:
			break;
	}
}


// functions called by mouse coords to respond to visual area commands based on DisplayMode

function prepVis(mpt) {
	switch (DisplayMode) {
		case 'matrix':
			if (VisMode != 'selected') {revealImage(mpt)};
			break;
		case 'paddle':
			if (VisMode != 'naked') {formatPaddles(mpt,'prep');}
			break;
		default:
			break;
		} 
}
function readVis(mpt) {
	switch (DisplayMode) {
		case 'paddle':
			formatPaddles(mpt,'slide');
			break;
		default:
			break;
		} 
}
function writeVis(mpt) {
	switch (DisplayMode) {
		case 'matrix':
            switch (VisMode) {
                case 'naked':
                    VisMode = 'selected';
                    expandImage(mpt);
                    break;
                case 'selected':    
                    VisMode = 'naked';
                    break;
            }
			break;
		case 'paddle':
			formatPaddles(mpt,'select');
			break;
		default:
			break;
		} 
}

function prepTimeline(mpt) {
    var thisIm = detectTMItem(mpt);
	switch (DisplayMode) {
		case 'matrix':
            placeImages();
            redrawImage(thisIm);
			break;
		case 'autoplay':
            drawFullImage(CurrImage);
            redrawImage(thisIm);
    		break;
		case 'paddle':
			if (VisMode == 'bISelect' || VisMode == 'fISelect') redrawImage(thisIm);
    		break;
		default:
			break;
	}
    timeline(ImNo);
    tMActiveControl(thisIm);
}

function readTimeline(mpt) {
        var thisIm = detectTMItem(mpt);
        if (TMState == "selected") {
            if (DisplayMode == "autoplay") {
                drawFullImage(CurrImage);
                redrawImage(thisIm);
            };
            if (DisplayMode == "matrix") {
                placeImages();
                redrawImage(thisIm);
            };
            if (DisplayMode == "paddle") {
                redrawImage(thisIm);
            };
            timeline(thisIm);
        }
}

function writeTimeline(mpt) { // write timeline given a mousepointer
	var thisIm = detectTMItem(mpt);	
	var mousey = [VisWidth/2, VisHeight/2];
	switch (DisplayMode) {
		case 'matrix':
			fullImage(thisIm);
			ImNo = thisIm;
			break;
		case 'autoplay':
            drawFullImage(CurrImage);
            redrawImage(thisIm);
    		break;
		case 'paddle':
			switch (VisMode) {
				case 'bISelect':
					BImNo = thisIm;
					VisMode='naked';
					init();
					break;
				case 'fISelect':
					setNewImage(thisIm);
					VisMode='naked';
					init();
					break;
				default:
					break;
			}
    		break;
		default:
			break;
	}
}

function timeline(n,c) { //display Timeline given an item number
	if (!c) c="#ff4466";
    ctxTM.beginPath();
    ctxTM.clearRect(0, 0, tMacWidth, VisHeight);
    ctxTM.closePath();
    ctxTM.beginPath(); // Drw slider
    ctxTM.lineWidth = 10;
    ctxTM.lineCap = "round";
    ctxTM.strokeStyle="#4466ff";
    ctxTM.moveTo(tMacWidth/2, 0);
    ctxTM.lineTo(tMacWidth/2, VisHeight);
    ctxTM.stroke();
    ctxTM.closePath();
    ctxTM.beginPath(); // Draw curr location
    ctxTM.lineWidth = 10;
    ctxTM.lineCap = "round";
    ctxTM.strokeStyle=c;
    ctxTM.moveTo(Math.floor(tMacWidth/2)-CtrlHeight, Math.floor(n/NumImages*(VisHeight)));
    ctxTM.lineTo(Math.floor(tMacWidth/2)+CtrlHeight, Math.floor(n/NumImages*(VisHeight)));
    ctxTM.stroke();
    ctxTM.closePath();    
}

// Write active control onto timeline
function tMActiveControl(n,c) { //display Timeline control given an item number
		if (!c) c="#ff88cc";
        ctxTM.beginPath(); // Draw hover location
        ctxTM.lineWidth = 10;
        ctxTM.lineCap = "round";
        ctxTM.strokeStyle=c;
        ctxTM.moveTo(Math.floor(tMacWidth/2-CtrlHeight), Math.floor(n/NumImages*VisHeight));
        ctxTM.lineTo(Math.floor(tMacWidth/2+CtrlHeight), Math.floor(n/NumImages*VisHeight));
        ctxTM.stroke();
        ctxTM.closePath();            
}

// Image processing routines
var ImNo = 1, FirstImage=1, DispDelay = 1000, CurrImage = new Image(), MyTimeout; // set up Global image manipulation variables
// set globals to hold image sizes etc for use across three matrix drawing routines.
var tileSize, numImAcross, numImDown; // to be GlobCapped and moved to line above

function setImages() {
    placeImages();
    timeline(ImNo);
}

function placeImages() {
    var i = 1, tileMargin = 1, imgname = "im", img = new Image();
    tileSize = Math.floor(Math.sqrt(VisHeight*VisWidth/NumImages)*.995);
    numImAcross = Math.floor(VisWidth/tileSize);
    numImDown = Math.floor(VisHeight/tileSize); // calculate globals used by all matrix routines.
    ctxVS.clearRect(0, 0, VisWidth, VisHeight);
    ctxVS.closePath();
    ctxVS.beginPath();
    for (i = 1; i <= NumImages; i++) {
        imgname = "im" + i;
        img = document.getElementById(imgname);
        ctxVS.drawImage(img, ((i - 1) % numImAcross) * tileSize, Math.floor((i -1)/ numImAcross) * tileSize, tileSize-tileMargin, tileSize-tileMargin);
    }
}

function detectImage(mpt){ // convert mousepointer to image number for matrix view
    // identify which image is under the mouse
    thisIm = Math.ceil(mpt[0] / tileSize) + (Math.floor(mpt[1] / tileSize)) * numImAcross;
    return thisIm;
}

function revealImage(mpt) {
    placeImages();
    redrawImage(detectImage(mpt));
}
function redrawImage(thisIm) {
    if (thisIm  !== ImNo) {
        // redraw the image under the mouse (TimeMachine of VisPanel) slightly larger
        var redrawSize = VisHeight/5, img = new Image(), newLeft, newTop;
        var imgname = "im" + thisIm;
        img = document.getElementById(imgname);
		if (DisplayMode == 'matrix') {
			newLeft = ((thisIm - 1) % numImAcross) * ( tileSize - (1/numImAcross*redrawSize)) ;
			newTop = Math.round((thisIm - numImAcross) / numImAcross) * (tileSize - (1/numImAcross*redrawSize));
		} else {
			newLeft = VisWidth/2;
			newTop = VisHeight/2;
		}
        ctxVS.drawImage(img, newLeft, newTop, redrawSize, redrawSize);
        timeline(ImNo);
	    tMActiveControl(thisIm);
    }
}
function drawFullImage(thisImg) {
        ctxVS.clearRect(0, 0, VisWidth, VisHeight);
        if (thisImg.width/thisImg.height < VisWidth/VisHeight) {
            ctxVS.drawImage(thisImg, (VisWidth-VisHeight*thisImg.width/thisImg.height)/2, 0, VisHeight*thisImg.width/thisImg.height, VisHeight);                    
        } else {
            ctxVS.drawImage(thisImg, 0, (VisHeight-VisWidth*thisImg.height/thisImg.width)/2, VisWidth, VisWidth*thisImg.height/thisImg.width);                    
        }
}
function expandImage(mpt) {
    ImNo = detectImage(mpt); // confirm the selection globally
    fullImage(ImNo);
    timeline(ImNo);
}

function fullImage(b) {
    // redraw the current image as large as possible on the canvas
    // part of storylines image display (based on http://thewhalehunt.org/whalehunt.html)
    var imgName = "im" + b, img = new Image(), img2 = new Image();
    img = document.getElementById(imgName);
    ctxVS.drawImage(img, 0, 0, 300, 300);
    img2.src = document.getElementById(imgName).src.replace("-150x150","").replace("kayak4earth.com","lifejacket.ebono.com.au");
    img2.onload = function() {
        drawFullImage(img2);
    };
    CurrImage = img2;
}
// function for autoplaying images - uses global variable MyTimeout
    function incIm() {
        fullImage(ImNo);
        timeline(ImNo);
        window.clearTimeout(MyTimeout);
        MyTimeout=setTimeout(incIm,DispDelay);
        ImNo += 1;
    }

function endTimeouts() { // clears all active Timeouts
        window.clearTimeout(MyTimeout);	
}

// Routines for placing stories rather than images

// Global variables from storylines interface (reduce no of globals)
var topicNo = 0;// Global variable to store topic under mouse
var thisPara = ""; // Global variable to store selected parameter
var thisId = ""; // Global variable to store pathmap ID of selected parameter
var theseTopics = ""; // Global variable to store selectd topic
var prev_topic = 7; // only output html on change of topic
var selectedItem, selectedId, selectedTopics, maxCount = 0; // global variables to size main and related topics based on count



function callPlaceStory(p,n) {
        var newText;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("tale").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET","http://lifejacket.ebono.com.au/LifeJacket/elements/get_text.php?p="+p,true);
        xmlhttp.send();
}



// Routines for managing Storylines panel


function searchList() {
    var searchText = document.getElementById("listSearch").value.toLowerCase(); 
    paraList = document.getElementById("fullList");
    listArray = paraList.getElementsByTagName('p');
    for (var i = 0; i < listArray.length; i++) {
        var itemText = listArray[i].innerHTML; 
        var lowerItemText = itemText.toLowerCase();
        var regex = new RegExp("^" + searchText, "i");
        var match = lowerItemText.match(regex); 
        var contains = lowerItemText.indexOf(searchText) != -1;
        if (match || contains) {
            listArray[i].style.display = "";
        } else {
            listArray[i].style.display = "none";
        }
    }
}
function ghostItem(iName, iNum) { // display grey version of item under mouse
    ctxVS.fillStyle = "rgba(205,225,255,.75)";
    ctxVS.fillRect(0,0,VisWidth,VisHeight); // fill canvas
    ctxVS.beginPath();
    ctxVS.moveTo(VisWidth/2,VisHeight/2);
    ctxVS.fillStyle = "rgba(255,255,205,.75)";
    ctxVS.arc(VisWidth/2,VisHeight/2,Math.round(VisHeight/6*Math.sqrt(iNum/maxStories)), 0, 2*Math.PI);
    ctxVS.fill(); // draw circle
    ctxVS.font = "20px Arial";
    ctxVS.textAlign="center";
    ctxVS.fillStyle = "rgba(170,165,255,.85)";
    ctxVS.fillText(iName,VisWidth/2,VisHeight/2); // Name the circle
}


function setItem(pName, pId, topics) { // fix the parameter when selected and display topics
    thisPara=pName;
    thisId=pId;
    theseTopics=topics; 
    var topicArr=theseTopics.split("|"); // Set up a topic array
    topicArr.splice(topicArr.length-1);  // remove the trailing element
    // colour the canvas
    ctxVS.fillStyle = "#ccffff";
    ctxVS.fillRect(0,0,VisWidth,VisHeight);
    // draw the central object
    ctxVS.beginPath();
    ctxVS.moveTo(VisWidth/2,VisHeight/2);
    ctxVS.fillStyle = "rgba(220,120,120,1)";
    ctxVS.arc(VisWidth/2,VisHeight/2,VisHeight/6,0,2*Math.PI);
    ctxVS.fill();
    // name the central object
    ctxVS.font = "20px Arial";
    ctxVS.textAlign="center";
    ctxVS.fillStyle = "#336633";
    ctxVS.fillText(pName,VisWidth/2,VisHeight/2);
    if (pName != "") {
        // update the content panel
        thisName=pName;
        var pNmArr=thisName.split("^"); // Set up a name array
    //    document.getElementById("tale").innerHTML = "<div id='item_0' class='black'><h2>" + pNmArr[0] + "</h2></div>";
        callPlaceStory(pId,0);
        // place the topics for this object on the canvas
        topicArr.forEach(placeTopic);
    }
    maxCount=0;
    // timeMachine(150); // when ready
}

function placeTopic(item, index, arr) { // place the topic based on the current array element
    var this_x=Math.round(VisWidth*0.5+VisHeight*0.33*(Math.sin(Math.PI*(0.333+0.333*index))));
    var this_y=Math.round(VisHeight*(0.5+0.33*(Math.cos(Math.PI*(0.333+0.333*index)))));
    var this_itemNo = index + 1;
    var theseItems = item;
    var topicMeta=theseItems.split("^"); // Separate topic name, id and count
    if (maxCount == 0) {
      maxCount = topicMeta[2];  //track the first (biggest) counter to set topic size
    };
    ctxVS.beginPath();
    ctxVS.moveTo(this_x,this_y);
    ctxVS.fillStyle = "rgba(225,255,125,1)";
    ctxVS.arc(this_x,this_y,(VisHeight/6)*Math.sqrt(topicMeta[2]/maxCount),0,2*Math.PI);
    ctxVS.fill(); 
    ctxVS.fillStyle = "rgba(55,55,255,1)";
    // name the topic
    ctxVS.font = "16px Arial";
    ctxVS.fillText(topicMeta[0],this_x, this_y);
//    document.getElementById("tale").innerHTML += "<div id='item_" + this_itemNo + "' class='grey'><h2>" + item + "</h2>"
//    document.getElementById("tale").innerHTML += "</div>"
//    console``.log(this_itemNo);
}

function selectTopic(mousey) {
    x = mousey[0];
    y = mousey[1];
    // identify which topic is under the mouse
    // console.log(x,y,VisWidth);
    var placement = Math.round(Math.sqrt(Math.pow((x-VisWidth/2),2)+Math.pow((y-VisHeight/2),2)));
    if (placement < VisHeight/6) { 
        topicOver=0; // we are on central disk
    } else {
        if (placement > VisHeight/2) {
            topicOver=7; // we are outside active area
        } else {
            topicAsin = Math.floor(Math.asin( (VisHeight/2 - y) / placement )*3/Math.PI);
            topicAcos = Math.floor(Math.acos( (VisWidth/2 - x) / placement )*3/Math.PI);
            if (topicAsin < 0) { // we are in the bottom half of the screen
                topicOver = (4+topicAcos)%6+1;
            } else {
                topicOver = 4-topicAcos;
            }
        } // END we are not outide the active area
    } // END we are not on the central disk
    if (topicOver != prev_topic) {
        if (prev_topic < 7) {document.getElementById("item_"+prev_topic).className = "grey";}
        if (topicOver < 7) {document.getElementById("item_"+topicOver).className = "black";}
        prev_topic = topicOver;
    } 

}

function mouse_coords(c, e, doFunc) {
    var rect = c.getBoundingClientRect(),
        x = Math.round(e.clientX - rect.left),
        y = Math.round(e.clientY - rect.top);
        ActivePanel = c.id;
        var mouse_pos = [x, y];
        mousePos = mouse_pos; 
        doFunc(mouse_pos);
}
