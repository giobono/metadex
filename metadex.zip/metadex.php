<?php
/*
Plugin Name:   Metadex
Plugin URI:    https://github.com/giobono/metadex
Description:   Add a metadata interface to WordPress
Version:       0.5
Author:        Geoff Ebbs
Author URI:    http://ebono.com.au/geoff-ebbs/
*/

function add_get_val() { 
    global $wp; 
    $wp->add_query_var('displayMode'); 
}

function mx_scripts() {
	wp_register_script('storylines', plugins_url('metadex/elements/storylines.js', _FILE_));
	wp_enqueue_script('storylines');
	wp_register_script('paddle', plugins_url('metadex/elements/paddle.js', _FILE_));
	wp_enqueue_script('paddle');
}

function mx_styles() {
	wp_register_style('metadex_styles', plugins_url('metadex/elements/metadex.css', _FILE_));
	wp_enqueue_style('metadex_styles');
}

function metadex_shortcodes_init() {
    function insert_metadex() {
        $displayMode = "matrix";
        if (get_query_var('displayMode') ) {
                $displayMode = get_query_var('displayMode');	
        }  
    ?>
        <div id="slContent" style="width:580px; height:560px">
            <div id="storyline">
                <canvas id="slCtrl" onmousemove="mouse_coords(slCtrlCv, event, readTimeline)" onclick="mouse_coords(slCtrlCv, event, writeTimeline)"><p>Old browser ol' bean. Get a new one!</p></canvas>				
                <canvas id="timeMachine" onmousemove="mouse_coords(timeMac, event, prepTimeline)" onmousedown="mouse_coords(timeMac, event, readTimeline)" onmouseup="mouse_coords(timeMac, event, writeTimeline)"><p>Old browser ol' bean. Get a new one!</p></canvas>
                <canvas id="metadex" onmousemove="mouse_coords(mdex, event, prepMdx)" onmousedown="mouse_coords(mdex, event, readMdx)" onmouseup="mouse_coords(mdex, event, writeMdx)"><p>Old browser ol' bean. Get a new one!</p></canvas>
            </div>
            <div id="visZone">
                <div id="visCtrl">
                    <div id="vC1" class="vCtrl" onclick="selectCtrl(1)"></div>
                    <div id="vC2" class="vCtrl"  onclick="selectCtrl(2)"></div>
                    <div id="vC3" class="vCtrl" onlick="selectCtrl(3)"></div>
                    <div id="vC4" class="vCtrl" onclick="selectCtrl(4)"></div>							
                </div>
                <div id="visMode" >
                    <div id="vMMatrix" class="vMMode" onclick="selectMode('matrix')">Matrix</div>
                    <div id="vMAutoplay" class="vMMode" onclick="selectMode('autoplay')">Autoplay</div>
                    <div id="vMPaddle" class="vMMode" onclick="selectMode('paddle')">Paddle</div>
                    <div id="vMMetadex" class="vMMode" onclick="selectMode('metadex')">Metadex</div>
                </div>
                <canvas id="visuals" onmousemove="mouse_coords(visArea, event, prepVis)" onmousedown="mouse_coords(visArea, event, readVis)" onmouseup="mouse_coords(visArea, event, writeVis)"><p>Old browser ol' bean. Get a new one!</p></canvas>
            </div>
        </div>
        <div class="hidden">
            <!-- setup content array in this hidden section to initialise javascript and canvas -->
            <img id="leftArrow" src="/wordpress/wp-content/plugins/metadex/images/lArrow.png">
            <img id="rightArrow" src="/wordpress/wp-content/plugins/metadex/images/rArrow.png">
            <img id="pauseCtrl" src="/wordpress/wp-content/plugins/metadex/images/Pause.png">
            <img id="speedCtrl" src="/wordpress/wp-content/plugins/metadex/images/Speed.png">
            <img id="moveImage" src="/wordpress/wp-content/plugins/metadex/images/moveImage.png">
            <img id="formatImage" src="/wordpress/wp-content/plugins/metadex/images/formatImage.png">
            <?php // extract list of images from wordpress 
                global $wpdb;
                $sql3 = "SELECT id, post_date, post_title, guid FROM $wpdb->posts where post_type='attachment' and post_mime_type like 'image/%';";
                $result3 = $wpdb->get_results( $sql3, OBJECT );
                echo "<script>var NumImages=".$wpdb->num_rows."</script>\n"; //pass global variable
                if ($wpdb->num_rows > 0) {
                    // output data of each row (converting original image name to thumbnail)
                    $imNum = 0;
                    while($row = $wpdb->fetch_assoc()) {
                        $imNum = $imNum + 1;
                        echo "<img id='im".$imNum."' alt='".$row["guid"]."' src='".substr($row["guid"],0,strrpos($row["guid"],"."))."-150x150".strrchr($row["guid"],".")."'>\n";
                    }
                }
            ?>
            <script>
                // replace missing thumbnails with original image
                var img = new Image(), imgSrc;
                for (i = 1; i <= NumImages; i++) {
                    imgname = "im" + i;
                    img = document.getElementById(imgname);
                    imgSrc = img.src;
                    if (img.width == 0) {document.getElementById(imgname).src=imgSrc.replace("-150x150","");}
                }
            </script>
        </div>
        <script>
            // Global variables calculated from DOM object for placing, redrawing and reading
            var VisWidth = Math.floor(document.getElementById("slContent").offsetWidth*.6),
                VisHeight = Math.floor(document.getElementById("slContent").offsetHeight*.95),
                tMacWidth = Math.floor(VisWidth/6), DisplayMode = "<?= $displayMode?>", CtrlHeight = 25;
            // Set up canvases for mouse activity
            // Canvases need to be sized in DOM so that images are not stretched by CSS
            var timeMac = document.getElementById("timeMachine"); // Get the canvas
            var ctxTM = timeMac.getContext("2d");
            timeMac.width = tMacWidth;
            timeMac.height = VisHeight;
            var slCtrlCv = document.getElementById("slCtrl"); // Get the canvas
            var ctxSC = slCtrlCv.getContext("2d");
            slCtrlCv.width = tMacWidth*4;
            slCtrlCv.height = CtrlHeight;
            var mdex = document.getElementById("metadex"); // Get the canvas
            var ctxMx = mdex.getContext("2d");
            mdex.width = tMacWidth*3;
            mdex.height = VisHeight;
            var visCtrlDv = document.getElementById("visCtrl"); // Get the Div
            visCtrlDv.width = tMacWidth/2;
            visCtrlDv.height = CtrlHeight;
            var visModeDv = document.getElementById("visMode"); // Get the mode div
            visModeDv.width = tMacWidth/2;
            visModeDv.height = CtrlHeight;
            var visArea = document.getElementById("visuals"); // Get the canvas
            var ctxVS = visArea.getContext("2d");
            visArea.width = VisWidth;
            visArea.height = VisHeight;
            document.addEventListener('DOMContentLoaded', function() {
                setImages();
            }, false);
        </script>
    <?php
    }
    add_shortcode('metadex', 'insert_metadex');
}

add_action ('wp_enqueue_scripts', 'mx_scripts');
add_action ('wp_enqueue_scripts', 'mx_styles');
add_action('init','add_get_val');
add_action('init', 'metadex_shortcodes_init');

?>