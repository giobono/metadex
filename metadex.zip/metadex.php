<?php
/*
Plugin Name:   Metadex
Plugin URI:    https://github.com/giobono/metadex
Description:   Add a metadata interface to WordPress
Version:       0.6.1 (create page with post_meta, shortcode, query or post_meta settings)
Author:        Geoff Ebbs
Author URI:    http://ebono.com.au/geoff-ebbs/
*/

function add_get_val() { 
    global $wp; 
    $wp->add_query_var('MdxVisMode'); // select visualisation mode 
    $wp->add_query_var('MdxSelMode'); // select Selection mode 
    $wp->add_query_var('MdxVisControls'); // select Visualisation control settings
    $wp->add_query_var('MdxVBImNo'); // Select the Background image 
    $wp->add_query_var('MdxVFImNo'); // Select the image to float
    $wp->add_query_var('MdxVBLeft'); // Select Section of background image
    $wp->add_query_var('MdxVFTop'); // place float frame
    $wp->add_query_var('SavePage'); // call from jS to save page
    $wp->add_query_var('mxPMeta'); // Page meta data to be saved
    $wp->add_query_var('mxPTitle'); // Page title to be saved
}

function mxVElements() {
	wp_register_style('mdxVisualsStyle', plugins_url('metadex/elements/metadexVisuals.css', _FILE_));
	wp_enqueue_style('mdxVisualsStyle');
	wp_register_script('floatCtrl', plugins_url('metadex/elements/floatControl.js', _FILE_));
	wp_enqueue_script('floatCtrl');
	wp_register_script('float', plugins_url('metadex/elements/float.js', _FILE_));
	wp_enqueue_script('float');
}

function mxSElements() {
	wp_register_style('mdxSelectionStyle', plugins_url('metadex/elements/metadexSelection.css', _FILE_));
	wp_enqueue_style('mdxSelectionStyle');
	wp_register_script('metadex', plugins_url('metadex/elements/metadex.js', _FILE_));
	wp_enqueue_script('metadex');
}

function mxCreatePage($mdxTitle, $mdxMetadata) {
    // Create post object
    $anArray =  json_decode(stripslashes($mdxMetadata),true);
    $my_post = array(
        'post_title'    => $mdxTitle,
        'post_content'  => '[metadex]',
        'post_status'   => 'publish',
        'post_author'   => get_current_user_id(),
        'post_type'     => 'page',
        'meta_input'     => $anArray
    );

    // Insert the post into the database
    wp_insert_post( $my_post, '' );
}

function metadex_shortcodes_init() {
    add_shortcode('metadex', 'insert_metadex');
    function insert_metadex( $atts ) { 
        // Create wordpress page if required
        if (get_query_var('SavePage') ) {
            echo "Gunna try Oi am. ";
            if (get_query_var('mxPTitle') && get_query_var('mxPMeta')) {
                mxCreatePage(get_query_var('mxPTitle'), get_query_var('mxPMeta'));
            } 
        }
        
// FOLLOWING SECTION TO BE REWRITTEN AS A FUNCTION with defaults and error checks
        // Process any shortcodes set by administrator
        $a = shortcode_atts( array(
            'mdxselmode' => 'on',
            'mdxvismode' => 'matrix',
            'mdxvbimno' => 1,
            'mdxvfimno' => 2,
            'mdxviscontrols' => 'on',
            'mdxvbleft' => '0.25',
            'mdxvftop' => '0.5'
            ), $atts );
        $MdxVisMode = $a['mdxvismode']; // display from shortcode - can be overwritten in URL
        $MdxSelMode = $a['mdxselmode']; // default display - can be overwritten in URL
        $MdxVBImNo = $a['mdxvbimno']; // background image - can be overwritten in URL
        $MdxVFImNo = $a['mdxvfimno']; // floated image - can be overwritten in URL
        $MdxVisControls = $a['mdxviscontrols']; // floated image - can be overwritten in URL
        $MdxVFLeft = $a['mdxvbleft']; // floated image - can be overwritten in URL
        $MdxVFTop = $a['mdxvftop']; // floated image - can be overwritten in URL

        // Get settings for page from options table - Preferred method
        $MdxPageMeta = get_post_meta(get_the_ID(),'','true'); // create an array of the metadata for this post
        foreach ($MdxPageMeta as $mdxKey => $mdxValue) { // eliminate unwanted metadata and single value arrays
            $thisValue = $mdxValue[0];
            switch ($mdxKey) {
                case 'MdxVisMode':
                    $MdxVisMode = $thisValue;
                    break;
                case 'MdxSelMode':
                    $MdxSelMode = $thisValue;
                    break;
                case 'MdxVisControls':
                    $MdxVisControls = $thisValue;
                    break;
                case 'MdxVBImNo':
                    $MdxVBImNo = $thisValue;
                    break;
                case 'MdxVFImNo':
                    $MdxVFImNo = $thisValue;
                    break;
                case 'MdxVBLeft':
                    $MdxVBLeft = $thisValue;
                    break;
                case 'MdxVFTop':
                    $MdxVFTop = $thisValue;
                    break;
            }
        }
        
        // Override settings based on URL
        if (get_query_var('MdxVisMode') ) {
                $MdxVisMode = get_query_var('MdxVisMode');	
        }  
        if (get_query_var('MdxSelMode') ) {
                $MdxSelMode = get_query_var('MdxSelMode');	
        }  
        $MdxVisControls = "all"; // default display - can be overwritten in URL
        if (get_query_var('MdxVisControls') ) {
                $MdxVisControls = get_query_var('MdxVisControls');	
        }  
        if (get_query_var('MdxVBImNo') ) {
                $MdxVBImNo = get_query_var('MdxVBImNo');	
        }  
        if (get_query_var('MdxVFImNo') ) {
                $MdxVFImNo = get_query_var('MdxVFImNo');	
        }  
        if (get_query_var('MdxVBLeft') ) {
                $MdxVBLeft = get_query_var('MdxVBLeft');	
        }  
        if (get_query_var('MdxVFTop') ) {
                $MdxVFTop = get_query_var('MdxVFTop');	
        }  
        $globs = "var MdxVisMode = '". $MdxVisMode. "', ";
        $globs .= "MdxSelMode = '"   . $MdxSelMode. "', ";
        $globs .= "MdxVisControls= '". $MdxVisControls. "', ";
        $globs .= "MdxVBImNo = '"    . $MdxVBImNo . "', ";
        $globs .= "MdxVFImNo = '"    . $MdxVFImNo . "', ";
        $globs .= "MdxVBLeft = '"    . $MdxVBLeft . "', ";
        $globs .= "MdxVFTop  = '"    . $MdxVFTop  . "'";
        echo "<script>".$globs."</script>\n";
// END OF SECTION TO BE REWRITTEN AS A FUNCTION
?>
        <div id="mdxContent" style="width:580px; height:560px">
            <div id="mdxSelection">
                <canvas id="slCtrl" onmousemove="mouse_coords(slCtrlCv, event, readTimeline)" onclick="mouse_coords(slCtrlCv, event, writeTimeline)"><p>Old browser ol' bean. Get a new one!</p></canvas>
                <div id="mdxpanels">
                    <canvas id="timeMachine" onmousemove="mouse_coords(timeMac, event, prepTimeline)" onmousedown="mouse_coords(timeMac, event, readTimeline)" onmouseup="mouse_coords(timeMac, event, writeTimeline)"><p>Old browser ol' bean. Get a new one!</p></canvas>
                    <canvas id="mdxPanel" onmousemove="mouse_coords(mdex, event, revealMdx)" onmousedown="mouse_coords(mdex, event, identifyMdx)" onmouseup="mouse_coords(mdex, event, selectMdx)"><p>Old browser ol' bean. Get a new one!</p></canvas>
                </div>
            </div>
            <div id="visZone">
                <div id="visCtrl">
                    <div id="vC1" class="vCtrl" onclick="selectCtrl(1)"></div>
                    <div id="vC2" class="vCtrl"  onclick="selectCtrl(2)"></div>
                    <div id="vC3" class="vCtrl" onclick="selectCtrl(3)"></div>
                    <div id="vC4" class="vCtrl" onclick="selectCtrl(4)"></div>	
                </div>
                <div id="visMode" >
                    <div id="vMMatrix" class="vMMode" onclick="selectMode('matrix')">Matrix</div>
                    <div id="vMAutoplay" class="vMMode" onclick="selectMode('autoplay')">Autoplay</div>
                    <div id="vMPaddle" class="vMMode" onclick="selectMode('float')">Float</div>
                    <div id="vMMetadex" class="vMMode" onclick="selectMode('metadex')">Metadex</div>
                </div>
                <canvas id="visuals" onmousemove="mouse_coords(visArea, event, revealVis)" onmousedown="mouse_coords(visArea, event, identifyVis)" onmouseup="mouse_coords(visArea, event, selectVis)"><p>Old browser ol' bean. Get a new one!</p></canvas>
            </div>
        </div>
        <div class="hidden">
            <!-- setup content array in this hidden section to initialise javascript and canvas -->
            <img id="leftArrow" src="/wordpress/wp-content/plugins/metadex/images/lArrow.png">
            <img id="rightArrow" src="/wordpress/wp-content/plugins/metadex/images/rArrow.png">
            <img id="pauseCtrl" src="/wordpress/wp-content/plugins/metadex/images/Pause.png">
            <img id="speedCtrl" src="/wordpress/wp-content/plugins/metadex/images/Speed.png">
            <img id="moveImage" src="/wordpress/wp-content/plugins/metadex/images/moveImage.png">
            <img id="formatImage" src="/wordpress/wp-content/plugins/metadex/images/formatImage.png">
            <img id="savePage" src="/wordpress/wp-content/plugins/metadex/images/savepage.png">
            <?php // extract list of images from wordpress 
                global $wpdb;
                $sql3 = "SELECT id, post_date, post_title, guid FROM $wpdb->posts where post_type='attachment' and post_mime_type like 'image/%';";
                $result3 = $wpdb->get_results( $sql3, OBJECT );
                echo "<script>var NumImages=".$wpdb->num_rows."</script>\n"; //pass global variable
                if ($wpdb->num_rows > 0) {
                    // output data of each row (converting original image name to thumbnail)
                    $imNum = 0;
                    foreach ( $result3 as $row ) {
                        $imNum = $imNum + 1;
                        echo "<img id='im".$imNum."' alt='".$row->guid."' src='".substr($row->guid,0,strrpos($row->guid,"."))."-150x150".strrchr($row->guid,".")."'>\n";
                    }
                }
            ?>
            <script>
                // replace missing thumbnails with original image
                var img = new Image(), imgSrc;
                for (i = 1; i <= NumImages; i++) {
                    imgname = "im" + i;
                    img = document.getElementById(imgname);
                    imgSrc = img.src;
                    if (img.width == 0) {document.getElementById(imgname).src=imgSrc.replace("-150x150","");}
                }
            </script>
        </div>
        <?php if($MdxSelMode == "off") { ?>
            <style>:root {
                --VisWidPc: 100%;
                --SelDisp: none;
            }</style>
            <script>VisWidPc=1</script>
        <?php    } else { ?>
            <style>:root {
                --VisWidPc: 60%;
                --SelDisp: block;
            }</style>    
            <script>VisWidPc=0.6</script>
        <?php    } ?>
        <style>:root {--CtrlHeight: 25px;}</style>
        <script>CtrlHeight = 25</script>
        <script>
            // Global variables calculated from DOM object for placing, redrawing and reading
            var VisWidth = Math.floor(document.getElementById("mdxContent").offsetWidth*VisWidPc),
                VisHeight = Math.floor(document.getElementById("mdxContent").offsetHeight*.95),
                tMacWidth = Math.floor(VisWidth/6);
            // Set up canvases for mouse activity: variables set in PHP for css and js
            // Canvases need to be sized in DOM so that images are not stretched by CSS
            var timeMac = document.getElementById("timeMachine"); // Get the canvas
            var ctxTM = timeMac.getContext("2d");
            timeMac.width = tMacWidth;
            timeMac.height = VisHeight;
            var slCtrlCv = document.getElementById("slCtrl"); // Get the canvas
            var ctxSC = slCtrlCv.getContext("2d");
            slCtrlCv.width = tMacWidth*4;
            slCtrlCv.height = CtrlHeight;
            var mdex = document.getElementById("mdxPanel"); // Get the canvas
            var ctxMx = mdex.getContext("2d");
            mdex.width = tMacWidth*3;
            mdex.height = VisHeight;
            var visCtrlDv = document.getElementById("visCtrl"); // Get the Div
            visCtrlDv.width = tMacWidth/2;
            visCtrlDv.height = CtrlHeight;
            var visModeDv = document.getElementById("visMode"); // Get the mode div
            visModeDv.width = tMacWidth/2;
            visModeDv.height = CtrlHeight;
            var visArea = document.getElementById("visuals"); // Get the canvas
            var ctxVS = visArea.getContext("2d");
            visArea.width = VisWidth;
            visArea.height = VisHeight;            
            document.addEventListener('DOMContentLoaded', function() {
                switch (MdxVisMode) {
                    case 'float':
                        MdxVFInit();
                        break;
                    default:
                        setImages();
                        break;
                }
            }, false);
        </script>
    <?php
    }
}

add_action ('wp_enqueue_scripts', 'mxSElements');
add_action ('wp_enqueue_scripts', 'mxVElements');
add_action('init','add_get_val');
add_action('init', 'metadex_shortcodes_init');

?>