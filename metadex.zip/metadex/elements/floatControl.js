/* floatControl.js - Control the floating visualisation or Wordpress images in Metadex Visualisations
    This complements the display only tool (float.js) of the float visualisation section of the metadex library
    the prefix for components in this file is MdxVFC
    Relies on mdxVisualisation.js library -- MdxV -- for external functions Conventsions etc are explained there

    Author: Geoff Ebbs - giobono
    Developer: Ebono Institute
    Github: giobono/metadex
    License: CDDL-1.0
    Version: 0.6 <in Metadex v0.6>

    Originally developed as a prototype for research into MetaData interfaces as part of a Masters of Interactive Media - Griffith University 2018
*/

/* Overview of behaviour
    1 Draw background image
    2 Based on mousemode_mode and MdxFVmode determine colours and settingV
    3 Draw panel over box

    In step 2
    for mouse mode reveal
        on format identify zone and highlight box
        on FBIdentify move dBack to new position mP[x]
        on FFIdentify move frame to new position mP[y]
    
    for mouse mode identify
        switch mode to control mouse reveal behavour
        highlight edge of box to be moved
    
    For moouse mode select
        on format switch mode to pass control to mxC (selection) routines
        on FBIdentify store position mP[x] as BILeft
        on FFIdentify store position mP[x] as FITop
*/


/* Global variables
the Background Image No <MdxVBImNo>, and the top-left corner of its active portion <MdxVBIPos[]> are global variables available to all visualisations (declared in metadex.js)
    - the Metadex convention of passing measurements in pixels is used for these variabes

the Frame Image <FloatImNo>, Frame Position <FloatFDTop> and <FloatFDBottom> are global variables relevant only to the float routines.
    - The convention of float routines to store dimensions as percentages is used for these variables.

Colours of the panel selections are local to the formatFloat routine

This routine responds to MxMouseMode <mode - at the moment> and resets <MxVCMode> to determine the behaviour of the canvas in response to the mouse.

The current convention is that each change results in a return to the naked visualisation so that the results can be displayed. Local variables have been used to enable the inScreen emulation of the display if that is deemed desirable. It was not considered necessary for the development of the Minimum Viable Product.
*/
var FloatImNo, FloatFDTop, FloatFDBottom;

function drawPadForm(bImage, bSTop, bSLeft, bSWidth, bSHeight,  bSColor, bDTop, bDLeft,  bDWidth, bDHeight, bDColor, fDTop, fDBottom, fDColor, fW, fH, fSColor) { // calcs must match MouseZone calcs
	drawFullImage(bImage);
	drawBox(bDLeft,bDTop,bDWidth,bDHeight,bDColor);
	drawBox(bDLeft+bSLeft,bDTop+bSTop,bSWidth,bSHeight,bSColor);
	drawBox(bDLeft+bSLeft,fYTop*bSHeight+bDTop+bSTop,bSWidth,(fYBottom-fYTop)*bSHeight,fDColor);
    drawBox(bDLeft+bSLeft+fW,bDTop+bSTop+fYTop*bSHeight+((fYBottom-fYTop)*bSHeight-fH)/2,fW,fH,fSColor);
}

function drawBox(sX,sY,bW,bH,colour) {
	ctxVS.beginPath();
    ctxVS.lineWidth = Linewidth;
    ctxVS.strokeStyle=colour;
    ctxVS.moveTo(sX,sY);
    ctxVS.lineTo(sX+bW, sY);
    ctxVS.stroke();
    ctxVS.lineTo(sX+bW, sY+bH);
    ctxVS.stroke();
    ctxVS.lineTo(sX, sY+bH);
    ctxVS.stroke();
    ctxVS.lineTo(sX, sY);
    ctxVS.stroke();
}

function formatFloat(mP, mode) { // called from Canvas via revealVis in storylines.js, mouse pointer and mouse mode.
	var bDTop, bDLeft, bDHeight, bDWidth, bDColor='#ee6666', bISCropped, bSColor='#6666ee', fDTop, fDBottom, fDColor='#669966', fSColor='#cccc66', sZone='offscreen';
	endTimeouts(); // stop any other routines writing to the canvas
    if (mode == null) mode='reveal'; // set default mousemode
    if (MdxVCMode == null || MdxVCMode == 'naked') MdxVCMode='format'; //set default behaviour 
    
    /* Draw background image and calculate sizings for the rest of the routines
        Set up the dimensions based on the background image (the number of dimensions makes this function central and, so, large - there are so many)
        bD<property> and fD<property> are properties of the image (red and orange)
        bS<property> and fS<property> are properties of the selected area (blue and green)
        */
 	var bImage = new Image();
	if(MdxVBImNo > 0) {bImage.src = document.getElementById("im"+MdxVBImNo).src.replace("-150x150","");} 
		else {bImage.src = "/wordpress/wp-content/plugins/metadex/images/AloneAtSea.jpg";} // a default image is available	
    bISCropped = bImage.width/bImage.height > VisWidth/VisHeight; //calculations AND behaviours differ for tall images
	if (bISCropped) { // sides are cropped (image is full height, display is offset)
		bDWidth = VisWidth;
        bDLeft = 0;
		bDHeight = Math.floor(bImage.height * VisWidth / bImage.width); // displayed height = real width * screen width / real width
        bDTop = Math.floor((VisHeight - bDHeight)/2); // vertically centre image in screen
        // now calculate display zone
		bSWidth = Math.floor(bDHeight * VisWidth / VisHeight); // displayed height * screen width / screen height 
		bSHeight = bDHeight; 
        if (MdxVBIPos[0] == null) { //if there is no offset
            bSLeft = Math.floor((VisWidth-visWidth)/2); //horizontally centre the selection panel
        } else {
            bSLeft=Math.floor(MdxVBIPos[0]*bDWidth); // set left edge based on global variable (percentage)
        }  
    	bSTop = 0;
	} else { // top and bottom is cropped
		bDHeight = VisHeight;
        bDTop = 0;
		bDWidth = Math.floor(bImage.width * VisHeight/bImage.height); // displayed width = real width * screen height / real height
        bDLeft = Math.floor((VisWidth - bDWidth)/2); // horizontally centre image in screen
        // now calculate display zone
		bSWidth = bDWidth; 
		bSHeight = Math.floor(bDWidth * VisHeight / VisWidth);
		bSLeft=0; // set global variables to crop background image
        if (MdxVBIPos[1] == null) { //if there is no offset
            bSTop = Math.floor((VisHeight-visHeight)/2); // vertically centre the display panel
        } else {
            bSTop=Math.floor(MdxVBIPos[1]*bDHeight); // calculate offset from global variable (percentage)
        } // set right edge based on global variable
    }
    
    // establish frame dimensions
    var fW = Math.floor(((VisWidth/numDspIms)-fMar)*bSWidth/VisWidth);
    var fH = Math.floor(((VisHeight/numDspIms)-fMar)*bSHeight/VisHeight); //ratios currently same 

    // start working with the mouse position
    
    // determine the MouseZone (Calcs must match DrawPad function)        
	if (mP[0] > bDLeft && mP[0] < bDLeft+bDWidth && mP[1] > bDTop && mP[1] < bDTop+bDHeight) { // mouse inside background image
		if (mP[0] > bDLeft+bSLeft && mP[0] < bDLeft+bSLeft+bSWidth && mP[1] > bDTop+bSTop && mP[1] < bDTop+bSTop+bSHeight) { //mouse inside Bimage selection
			if (mP[0] > bDLeft+bSLeft && mP[0] < bDLeft+bSLeft+bSWidth && mP[1] > bDTop+bSTop+fYTop*bSHeight && mP[1] < bDTop+bSTop+fYBottom*bSHeight) { // mouse inside frame zone
				if (mP[0] >bDLeft+bSLeft+fW && mP[0] < bDLeft+bSLeft+2*fW && mP[1] > fYTop*bSHeight+bDTop+bSTop+((fYBottom-fYTop)*bSHeight-fH)/2 && mP[1] < fYTop*bSHeight+bDTop+bSTop+((fYBottom-fYTop)*bSHeight-fH)/2+fH) { // mouse in frame
					sZone = 'dFrame';
				} else {sZone = 'sFrame';}
			} else {sZone = 'sBack';} 
		} else {sZone = 'dBack';}
	} else {
        sZone = 'offScreen';
        if (mode=='select') { // handle off screen clicks first
            // go back to format mode on an offscreen click
            MdxVCMode = 'format'; //clicking off screen returns to format mode
            timeline(0,"white");
            drawPadForm(bImage, bSTop, bSLeft, bDTop, bDLeft, bSWidth, bSHeight, bDHeight, bDWidth, bSColor, fDTop, fDBottom, fDColor, bDColor);
        }
    }
    vMouse = mP; // set up local copy of mouse position to keep dragged item in frame
    switch (mode) { // and respond according to mouse mode
        case 'reveal': // following mouse movement
            switch (MdxVCMode) {
                case 'format':
                    // draw the basics
                    drawPadForm(bImage, bSTop, bSLeft, bSWidth, bSHeight,  bSColor, bDTop, bDLeft,  bDWidth, bDHeight, bDColor, fDTop, fDBottom, fDColor, fW, fH, fSColor);
                    if (mode == 'reveal') { // coming from mouseover. The mouse highlights the format 
                        switch (sZone) {
                            case 'dBack':
                                drawBox(bDLeft,bDTop,bDWidth,bDHeight,"red");
                                timeline(MdxVBImNo,bDColor);
                                break;
                            case 'sBack':
                                drawBox(bDLeft+bSLeft,bDTop+bSTop,bSWidth,bSHeight,"blue");
                                timeline(0,"white");
                                break;
                            case 'dFrame':
                                drawBox(bDLeft+bSLeft+fW,bDTop+bSTop+fYTop*bSHeight+((fYBottom-fYTop)*bSHeight-fH)/2,fW,fH,"yellow");
                                timeline(0,'white');
                                break;
                            case 'sFrame':
	                           drawBox(bDLeft+bSLeft,fYTop*bSHeight+bDTop+bSTop,bSWidth,(fYBottom-fYTop)*bSHeight,'lightgreen');
                                timeline(ImNoArr[1],fSColor);
                                break;
                            default:
                                break;
                        }			
                    }
                break;
                case 'FBSelect': // We are dragging the background selection box around 
                    if (mP[0] > VisWidth-bSWidth) {vMouse[0]=VisWidth-bSWidth;}; 
                    if (mP[1] > VisHeight-bSHeight) {vMouse[1]=VisHeight-bSHeight}; 
                    drawPadForm(bImage, bSTop, bSLeft, bSWidth, bSHeight,  bSColor, bDTop, bDLeft,  bDWidth, bDHeight, bDColor, fDTop, fDBottom, fDColor, fW, fH, fSColor);
                    if (bISCropped) {drawBox(vMouse[0],bDTop+bSTop,bSWidth,bSHeight,'bSColor')} else {drawBox(bDLeft+bSLeft,vMouse[1],bSWidth,bSHeight,'bSColor')};
                    timeline(MdxVBImNo,"blue");
                    break;
                case 'FFSelect':
                    if (mP[1] < bDTop+bSTop) {vMouse[1]=bDTop+bSTop};
                    if (mP[1] > bDTop+bSTop+bSHeight*(1-fYBottom+fYTop)) {vMouse[1]=bDTop+bSTop+bSHeight*(1-fYBottom+fYTop)};
                    drawPadForm(bImage, bSTop, bSLeft, bSWidth, bSHeight,  bSColor, bDTop, bDLeft,  bDWidth, bDHeight, bDColor, fDTop, fDBottom, fDColor, fW, fH, fSColor);
                    drawBox(bDLeft+bSLeft,vMouse[1],bSWidth,(fYBottom-fYTop)*bSHeight,'lightgreen');
                    timeline(MdxVBImNo,"yellow");
                    break;
                default: 
                    break;
            }
            break;
        case 'identify': // we are intiating a drag
            switch (sZone) {
                case 'sBack':
                    MdxVCMode = 'FBSelect'; // prepare for mouse Up
                    drawBox(bSLeft+bDLeft, bSTop+bDTop, bSWidth, bSHeight, bSColor); //draw box at mouse position
                    timeline(MdxVBImNo,"blue");
                    break;
                case 'sFrame':
                    MdxVCMode = 'FFSelect'
                    drawBox(bDLeft+bSLeft,mP[1],bSWidth,(fYBottom-fYTop)*bSHeight, fSColor);
                    timeline(ImNoArr[1],'yellow');
                    break;
                default:
                    break;
            }
            break;
        case 'select':
            switch (MdxVCMode) {
                case 'format':    
                    switch (sZone) {
                        case 'dBack': // Determine the background image
                            drawBox(bDLeft,bDTop,bDWidth,bDHeight,"red");
                            ctxVS.fillStyle='rgba(200,100,100,.5)';
                            ctxVS.fillRect(bDLeft,bDTop,bDWidth,bDHeight);
                            timeline(MdxVBImNo,"red");
                            MdxVCMode = 'FBIdentify';
                            break;
                        case 'sBack': // Se;ect the area of the background image to display
                            // follow the mouse up/down or left/right depending on aspect ratio
                            var currLeft=0, currTop=0;
                            if (bISCropped) { // sides are cropped 
                                currLeft=mP[0]; // set left edge based on mouse
                                currTop = bDTop+bSTop;
                            } else { // top and bottom is cropped
                                currLeft = bDLeft+bSLeft;
                                currTop=mP[1]; // set top edge based on mouse
                            }
                            drawBox(bDLeft+bSLeft,bDTop+currTop,bSWidth,bSHeight,bSColor);
                            timeline(0,"white");
                            MdxVCMode = 'FBSelect';
                            break;
                        case 'dFrame': // Determine the image in the frame
                            ctxVS.fillStyle='rgba(200,200,0,.5)';
                            ctxVS.fillRect(bDLeft+bSLeft+fW,bDTop+bSTop+fYTop*bSHeight+((fYBottom-fYTop)*bSHeight-fH)/2,fW,fH);
                            timeline(MdxVBImNo,"yellow");
                            MdxVCMode = 'FFIdentify';

                            break;
                        case 'sFrame': // Select the position of the frame
                            drawBox(bDLeft+bSLeft+fW,bDTop+bSTop+fYTop*bSHeight+((fYBottom-fYTop)*bSHeight-fH)/2,fW,fH,"yellow");
                            ctxVS.fillStyle='rgba(200,200,100,.5)';
                            ctxVS.fillRect(bDLeft+bSLeft+fW,bDTop+bSTop+fYTop*bSHeight+((fYBottom-fYTop)*bSHeight-fH)/2,fW,fH);
                            timeline(ImNoArr[1],'yellow');
                            MdxVCMode = 'FFSelect';
                            break;
                        default:
                            // go back to format mode on an offscreen click
                            MdxVCMode = 'format'; //clicking off screen returns to format mode
                            timeline(0,"white");
                            drawPadForm(bImage, bSTop, bSLeft, bSWidth, bSHeight,  bSColor, bDTop, bDLeft,  bDWidth, bDHeight, bDColor, fDTop, fDBottom, fDColor, fW, fH, fSColor);
                            break;                
                    }
                    break;
                case 'FBSelect': // set Global offset variable (percentage)
                    if (bISCropped) {
                        //if (mP[0] < bSLeft) {vMouse[0]=bSLeft;}; 
                        if (mP[0] > VisWidth-bSWidth) {vMouse[0]=VisWidth-bSWidth;}; 
                        MdxVBIPos[0]=vMouse[0]/bDWidth;
                        console.log("YAH", mP[0],vMouse[0],bSLeft,VisWidth, bSWidth);
                        MdxVBIPos[1]=0;
                    } else {
                        //if (mP[1] < bSTop) {vMouse[1]=bSTop}; 
                        if (mP[1] > VisHeight-bSHeight) {vMouse[1]=VisHeight-bSHeight}; 
                        console.log("YO", mP[1],vMouse[1],bSTop, VisHeight, bSHeight);
                        MdxVBIPos[0]=0;
                        MdxVBIPos[1]=vMouse[1]/bDHeight;
                    }
                    console.log("saving settings",MdxVBIPos);
                    MdxVCMode='naked';
                    MdxVFInit();
                    break;
                case 'FFSelect': // set Global framezone top variable (percentage)
                    var fYHeight = fYBottom-fYTop;
                    if (mP[1] < bDTop+bSTop) {vMouse[1]=bDTop+bSTop;}
                    if (mP[1] > bDTop+bSTop+bSHeight*(1-fYBottom+fYTop)) {vMouse[1]=bDTop+bSTop+bSHeight*(1-fYBottom+fYTop);}
                    fYTop=(vMouse[1]-(bDTop+bSTop))/bSHeight; // set fraction of display for top of frameZone
                    fYBottom=fYTop+fYHeight;
                    MdxVCMode='naked';
                    MdxVFInit();
                    break;
            }
        }
    }