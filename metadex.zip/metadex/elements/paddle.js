

function drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor) {
	drawFullImage(bImage);
	drawBox(bDLeft,bDTop,visWidth,visHeight,bDColor);
	drawBox(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight,bIColor);
	drawBox(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight,fDColor);
}

function formatPaddles(mP, mode) { // called from Canvas via prepVis in storylines.js, mouse pointer and mouse mode.
	var bDTop, bDLeft, bDHeight, bDWidth, bDColor='#6666ee', fDTop, fDBottom, fDColor='#cccc66', bIColor='#ee6666', sZone='offscreen';
 	var bImage = new Image();
	if (!mode) mode='prep';
    // Set up the dimensions based on the background image (the number of dimensions makes this function central and, so, large - there are so many)
    
	if(BImNo > 0) {bImage.src = document.getElementById("im"+BImNo).src.replace("-150x150","").replace("kayak4earth.com","lifejacket.ebono.com.au");} 
		else {bImage.src = "/word(bImage.width/bImage.height > visWidth/visHeight) {press/wp-content/themes/Kayak/images/AloneAtSea.jpg";}	
	if (bImage.width/bImage.height > VisWidth/VisHeight) { // sides are cropped
		bDWidth = VisWidth;
		bDHeight = bImage.height * VisWidth / bImage.width; // displayed height = real height * screen width / real width
		visWidth = bDHeight * VisWidth / VisHeight; // displayed height * screen width / screen height 
		visHeight = bDHeight; 
		bILeft = (VisWidth-visWidth)/2; // set global variables to crop background image
		bITop = 0;
	} else { // top and bottom is cropped
		bDHeight = VisHeight;
		bDWidth = bImage.height * VisHeight/VisWidth; // displayed width = real width * screen height / real height
		visWidth = bDWidth; 
		visHeight = bDWidth * VisHeight / VisWidth;
		bILeft=0; // set global variables to crop background image
		bITop = (VisHeight-visHeight)/2;
	}
	bDLeft = (VisWidth-visWidth)/2; 
	bDTop = (VisHeight-visHeight)/2;
        
	endTimeouts(); // stop any other routines writing to the canvas
    
    
    // determine what zone the mouse is in    
    
	if (mP[0] > bDLeft-bILeft && mP[0] < bDLeft-bILeft+bDWidth && mP[1] > bDTop-bITop && mP[1] < bDTop-bITop+bDHeight) { // mouse inside background image
		if (mP[0] > bDLeft && mP[0] < bDLeft+visWidth && mP[1] > bDTop && mP[1] < bDTop+bDHeight) { //mouse inside displayed bdImage
			if (mP[0] > bDLeft && mP[0] < bDLeft+visWidth && mP[1] > bDTop+fYTop*visHeight && mP[1] < bDTop+fYBottom*visHeight) { // mouse inside frame zone
				if (mP[0] > bDLeft && mP[0] < bDLeft+visWidth && mP[1] > bDTop+fYTop*visHeight && mP[1] < bDTop+fYTop*visHeight+Linewidth) { // mouse in frame top line
					sZone = 'frameline';
				} else {sZone = 'frames';}
			} else {sZone = 'dBack';} 
		} else {sZone = 'back';}
	} else sZone = 'offScreen';

    // and go back to format mode on an offscreen click
    
    if (sZone == 'offScreen' && mode == 'select') { // That's all folks 
        VisMode = 'format'; 
        timeline(0,"white");
        drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor);        

    } else { // handle the mouse action
        
        // draw the basics
        drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor);
        if (mode == 'prep') { // coming from mouseover. The mouse highlights the format 
            switch (sZone) {
                case 'back':
                    drawBox(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight,"red");
                    timeline(BImNo,bIColor);
                    break;
                case 'dBack':
                    drawBox(bDLeft,bDTop,visWidth,visHeight,"blue");
                    timeline(0,"white");
                    break;
                case 'frames':
                    drawBox(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight,"yellow");
                    timeline(ImNoArr[1],fDColor);
                    break;
                default:
                    break;
            }			
        }
        if (mode == 'slide') { // coming from mouse down - switch VisMode so that selected format moves with mouse
            switch (sZone) {
                case 'dBack':
                    VisMode = ''
                    drawBox(mP[0],bDTop,visWidth,visHeight,bDColor);
                    ctxVS.beginPath();
                    ctxVS.lineWidth = Linewidth;
                    ctxVS.strokeStyle="blue";
                    ctxVS.moveTo(bDLeft,bDTop);
                    ctxVS.lineTo(bDLeft,bDTop+visHeight);
                    ctxVS.stroke();
                    timeline(0,"white");
                    break;
                case 'frames':
                    //fYTop = (mP[1]-bITop)/visHeight;
                    drawBox(bDLeft,mP[1],visWidth,(fYBottom-fYTop)*visHeight,"yellow");
                    ctxVS.fillStyle='rgba(200,200,100,.5)';
                    ctxVS.fillRect(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight);
                    timeline(ImNoArr[1],'yellow');
                    break;
                default:
                    break;
            }
        } 
        if (mode == 'select') { // coming from mouse up (click)
            if (VisMode == 'format') {
                switch (sZone) {
                    case 'back':
                        drawBox(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight,"red");
                        ctxVS.fillStyle='rgba(200,100,100,.5)';
                        ctxVS.fillRect(bDLeft-bILeft,bDTop-bITop,bDWidth,bDHeight);
                        timeline(BImNo,"red");
                        VisMode = 'bISelect';
                        break;
                    case 'dBack':
                        drawBox(bDLeft,bDTop,visWidth,visHeight,bDColor);
                        ctxVS.beginPath();
                        ctxVS.lineWidth = Linewidth;
                        ctxVS.strokeStyle="blue";
                        ctxVS.moveTo(bDLeft,bDTop);
                        ctxVS.lineTo(bDLeft,bDTop+visHeight);
                        ctxVS.stroke();
                        timeline(0,"white");
                        VisMode = 'bISlide';
                        break;
                    case 'frames':
                        drawBox(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight,"yellow");
                        ctxVS.fillStyle='rgba(200,200,100,.5)';
                        ctxVS.fillRect(bDLeft,fYTop*visHeight+bDTop-bITop,visWidth,(fYBottom-fYTop)*visHeight);
                        timeline(ImNoArr[1],'yellow');
                        VisMode = 'fISelect';
                        break;
                    default:
                        break;
                }			
            } else {
                    VisMode = 'format'; //clicking off screen returns to format mode
                    timeline(0,"white");
                    drawPadForm(bImage, bDTop, bDLeft, visWidth, visHeight, bDHeight, bDWidth, bDColor, fDTop, fDBottom, fDColor, bIColor);

            }
        }
    }

}

function drawBox(sX,sY,bW,bH,colour) {
	ctxVS.beginPath();
    ctxVS.lineWidth = Linewidth;
    ctxVS.strokeStyle=colour;
    ctxVS.moveTo(sX,sY);
    ctxVS.lineTo(sX+bW, sY);
    ctxVS.stroke();
    ctxVS.lineTo(sX+bW, sY+bH);
    ctxVS.stroke();
    ctxVS.lineTo(sX, sY+bH);
    ctxVS.stroke();
    ctxVS.lineTo(sX, sY);
    ctxVS.stroke();
}
