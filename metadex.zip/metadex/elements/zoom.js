/* zoom.js - nested grid of images as pixels as a visualisation in Metadex Visualisations
    This is the display only tool of the zoomer visualisation section of the metadex library
    the prefix for components in this file is MdxVZ
    Relies on mdxVisualisation.js library -- MdxV -- for external functions
    Integrates with mdxSelection.js -- MdxS -- for selection of images

    Author: Geoff Ebbs - giobono
    Developer: Ebono Institute
    Github: giobono/metadex
    License: CDDL-1.0
    Version: 0.6.1 <in Metadex v0.6.1>

    Originally developed as a prototype for research into MetaData interfaces as part of a Masters of Interactive Media - Griffith University 2018
    
    Conventions etc explained in metadex.js
    
*/
/* Global variables

    MdxVBImNo, MdxVBTop and MdxVBLeft, LineWidth, VisWidth and VisHeight all come from general Metadex framework
*/
var ZoomFactor=3, CurrZoomFactor=1; //Amount to zoom on each iteration

function MdxVZInit() {
    CurrZoomFactor = 1;
    endTimeouts();
	mousePos = [VisWidth/2, VisHeight/2]; // assume mouse centre screeen
	placeBImage(MdxVBImNo);
}

function zoomReveal(mousey) {
    // draw a box where the next zoom will be
    var vMouse = mousey;
	placeBImage(MdxVBImNo);
    if (mousey[0] > visWidth*(ZoomFactor-1)/ZoomFactor) {vMouse[0]=visWidth*(ZoomFactor-1)/ZoomFactor}; 
    if (mousey[1] > visHeight*(CurrZoomFactor-1)/CurrZoomFactor) {vMouse[1]=visHeight*(ZoomFactor-1)/ZoomFactor}; 
    drawBox(vMouse[0], vMouse[1], VisWidth/ZoomFactor, visHeight/ZoomFactor,"white");
}
function zoomSelect(mousey) {
    // draw a box where the next zoom will be\
    var vMouse = mousey;
    if (mousey[0] > visWidth*(ZoomFactor-1)/ZoomFactor) {vMouse[0]=visWidth*(ZoomFactor-1)/ZoomFactor}; 
    if (mousey[1] > visHeight*(ZoomFactor-1)/ZoomFactor) {vMouse[1]=visHeight*(ZoomFactor-1)/ZoomFactor}; 
	zoomImage(MdxVBImNo,vMouse);
    CurrZoomFactor=CurrZoomFactor*ZoomFactor;
}

function zoomImage(thisIm,vMouse) {
 	var bImage = new Image();
	if(thisIm > 0) {bImage.src = document.getElementById("im"+thisIm).src.replace("-150x150","");} 
		else {bImage.src = "/wordpress/wp-content/plugins/metadex/images/AloneAtSea.jpg";}
	visWidth = VisWidth; // set up local variables (for future scaling applications)
	visHeight = VisHeight;
    bDLeft = vMouse[0]+MdxVBIPos[0]*bImage.width;  // set left edge based on sent variable 
    bDTop  = vMouse[1]+MdxVBIPos[1]*bImage.height; // set top edge based on sent variable
	if (bImage.width/bImage.height > visWidth/visHeight) {
		ctxVS.drawImage(bImage, bDLeft , bDTop, visWidth*bImage.height/visHeight/MdxZoomFactor, bImage.height/CurrZoomFactor, 0, 0, visWidth, visHeight );	
	} else {
		ctxVS.drawImage(bImage, bDLeft, bDTop, bImage.width/MdxZoomFactor, visHeight*bImage.width/visWidth/CurrZoomFactor, 0, 0, visWidth, visHeight );
	}
}