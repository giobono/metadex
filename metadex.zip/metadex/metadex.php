<?php
/*
Plugin Name:   Metadex
Plugin URI:    https://github.com/giobono/metadex
Description:   Add a metadata interface to WordPress
Version:       0.5 (moving toward 0.6)
Author:        Geoff Ebbs
Author URI:    http://ebono.com.au/geoff-ebbs/
*/

function add_get_val() { 
    global $wp; 
    $wp->add_query_var('MdxVisMode'); // select visualisation mode 
    $wp->add_query_var('MdxSelMode'); // select Selection mode 
    $wp->add_query_var('MdxVisControls'); // select Visualisation control settings
    $wp->add_query_var('SavePage'); // save page if requested
    $wp->add_query_var('mxPTitle'); // title of saved page
    $wp->add_query_var('mxPContent'); // content for saved page
}

function mxVElements() {
	wp_register_style('mdxVisualsStyle', plugins_url('metadex/elements/metadexVisuals.css', _FILE_));
	wp_enqueue_style('mdxVisualsStyle');
	wp_register_script('paddle', plugins_url('metadex/elements/paddle.js', _FILE_));
	wp_enqueue_script('paddle');
	wp_register_script('float', plugins_url('metadex/elements/float.js', _FILE_));
	wp_enqueue_script('float');
}

function mxSElements() {
	wp_register_style('mdxSelectionStyle', plugins_url('metadex/elements/metadexSelection.css', _FILE_));
	wp_enqueue_style('mdxSelectionStyle');
	wp_register_script('metadex', plugins_url('metadex/elements/metadex.js', _FILE_));
	wp_enqueue_script('metadex');
}

function mxCreatePage($mxTitle, $mxContent) {
    // Create post object
    $my_post = array(
      'post_title'    => $mxTitle,
      'post_content'  => $mxContent,
      'post_status'   => 'publish',
      'post_author'   => get_current_user_id(),
      'post_type'     => 'page'
    );

    // Insert the post into the database
    wp_insert_post( $my_post, '' );
}

function metadex_shortcodes_init() {
    add_shortcode('metadex', 'insert_metadex');
    function insert_metadex( $atts ) { 
        if (get_query_var('SavePage') ) {
            if (get_query_var('mxPTitle') &&  get_query_var('mxPContent') ) {
                mxCreatePage(get_query_var('mxPTitle'), get_query_var('mxPContent'));                
            } else echo "YAAAARRK<br>\n";
        }  else {
            echo "NUP<br>\n";
        }
        $a = shortcode_atts( array(
            'mdxselmode' => 'on',
            'mdxvismode' => 'matrix',
            'mdxvfbimno' => '1',
            'mdxvffimno' => 22,
            ), $atts );
        $MdxVisMode = $a['mdxvismode']; // default display - can be overwritten in URL
        if (get_query_var('MdxVisMode') ) {
                $MdxVisMode = get_query_var('MdxVisMode');	
        }  
        $MdxSelMode = $a['mdxselmode']; // default display - can be overwritten in URL
        if (get_query_var('MdxSelMode') ) {
                $MdxSelMode = get_query_var('MdxSelMode');	
        }  
        $MdxVisControls = "all"; // default display - can be overwritten in URL
        if (get_query_var('MdxVisControls') ) {
                $MdxVisControls = get_query_var('MdxVisControls');	
        }  
        $MdxVFBImNo = $a['mdxvfbimno'];
        $MdxVFFImNo = $a['mdxvffimno'];
    ?>
        <div id="mdxContent" style="width:580px; height:560px">
            <div id="mdxSelection">
                <canvas id="slCtrl" onmousemove="mouse_coords(slCtrlCv, event, readTimeline)" onclick="mouse_coords(slCtrlCv, event, writeTimeline)"><p>Old browser ol' bean. Get a new one!</p></canvas>
                <div id="mdxpanels">
                    <canvas id="timeMachine" onmousemove="mouse_coords(timeMac, event, prepTimeline)" onmousedown="mouse_coords(timeMac, event, readTimeline)" onmouseup="mouse_coords(timeMac, event, writeTimeline)"><p>Old browser ol' bean. Get a new one!</p></canvas>
                    <canvas id="mdxPanel" onmousemove="mouse_coords(mdex, event, prepMdx)" onmousedown="mouse_coords(mdex, event, readMdx)" onmouseup="mouse_coords(mdex, event, writeMdx)"><p>Old browser ol' bean. Get a new one!</p></canvas>
                </div>
            </div>
            <div id="visZone">
                <div id="visCtrl">
                    <div id="vC1" class="vCtrl" onclick="selectCtrl(1)"></div>
                    <div id="vC2" class="vCtrl"  onclick="selectCtrl(2)"></div>
                    <div id="vC3" class="vCtrl" onclick="selectCtrl(3)"></div>
                        <div id="vC4" class="vCtrl" onclick="selectCtrl(4)"></div>	
                </div>
                <div id="visMode" >
                    <div id="vMMatrix" class="vMMode" onclick="selectMode('matrix')">Matrix</div>
                    <div id="vMAutoplay" class="vMMode" onclick="selectMode('autoplay')">Autoplay</div>
                    <div id="vMPaddle" class="vMMode" onclick="selectMode('paddle')">Paddle</div>
                    <div id="vMMetadex" class="vMMode" onclick="selectMode('metadex')">Metadex</div>
                </div>
                <canvas id="visuals" onmousemove="mouse_coords(visArea, event, prepVis)" onmousedown="mouse_coords(visArea, event, readVis)" onmouseup="mouse_coords(visArea, event, writeVis)"><p>Old browser ol' bean. Get a new one!</p></canvas>
            </div>
        </div>
        <div class="hidden">
            <!-- setup content array in this hidden section to initialise javascript and canvas -->
            <img id="leftArrow" src="/wordpress/wp-content/plugins/metadex/images/lArrow.png">
            <img id="rightArrow" src="/wordpress/wp-content/plugins/metadex/images/rArrow.png">
            <img id="pauseCtrl" src="/wordpress/wp-content/plugins/metadex/images/Pause.png">
            <img id="speedCtrl" src="/wordpress/wp-content/plugins/metadex/images/Speed.png">
            <img id="moveImage" src="/wordpress/wp-content/plugins/metadex/images/moveImage.png">
            <img id="formatImage" src="/wordpress/wp-content/plugins/metadex/images/formatImage.png">
            <img id="savePage" src="/wordpress/wp-content/plugins/metadex/images/savepage.png">
            <?php // extract list of images from wordpress 
                global $wpdb;
                $sql3 = "SELECT id, post_date, post_title, guid FROM $wpdb->posts where post_type='attachment' and post_mime_type like 'image/%';";
                $result3 = $wpdb->get_results( $sql3, OBJECT );
                echo "<script>var NumImages=".$wpdb->num_rows."</script>\n"; //pass global variable
                if ($wpdb->num_rows > 0) {
                    // output data of each row (converting original image name to thumbnail)
                    $imNum = 0;
                    foreach ( $result3 as $row ) {
                        $imNum = $imNum + 1;
                        echo "<img id='im".$imNum."' alt='".$row->guid."' src='".substr($row->guid,0,strrpos($row->guid,"."))."-150x150".strrchr($row->guid,".")."'>\n";
                    }
                }
            ?>
            <script>
                // replace missing thumbnails with original image
                var img = new Image(), imgSrc;
                for (i = 1; i <= NumImages; i++) {
                    imgname = "im" + i;
                    img = document.getElementById(imgname);
                    imgSrc = img.src;
                    if (img.width == 0) {document.getElementById(imgname).src=imgSrc.replace("-150x150","");}
                }
            </script>
        </div>
        <?php if($MdxSelMode == "off") { ?>
            <style>:root {
                --VisWidPc: 100%;
                --SelDisp: none;
            }</style>
            <script>VisWidPc=1</script>
        <?php    } else { ?>
            <style>:root {
                --VisWidPc: 60%;
                --SelDisp: block;
            }</style>    
            <script>VisWidPc=0.6</script>
        <?php    } ?>
        <style>:root {--CtrlHeight: 25px;}</style>
        <script>CtrlHeight = 25</script>
        <script>
            // Global variables calculated from DOM object for placing, redrawing and reading
            var VisWidth = Math.floor(document.getElementById("mdxContent").offsetWidth*VisWidPc),
                VisHeight = Math.floor(document.getElementById("mdxContent").offsetHeight*.95),
                tMacWidth = Math.floor(VisWidth/6), MdxVisMode = "<?= $MdxVisMode?>";
            // Set up canvases for mouse activity: variables set in PHP for css and js
            // Canvases need to be sized in DOM so that images are not stretched by CSS
            var timeMac = document.getElementById("timeMachine"); // Get the canvas
            var ctxTM = timeMac.getContext("2d");
            timeMac.width = tMacWidth;
            timeMac.height = VisHeight;
            var slCtrlCv = document.getElementById("slCtrl"); // Get the canvas
            var ctxSC = slCtrlCv.getContext("2d");
            slCtrlCv.width = tMacWidth*4;
            slCtrlCv.height = CtrlHeight;
            var mdex = document.getElementById("mdxPanel"); // Get the canvas
            var ctxMx = mdex.getContext("2d");
            mdex.width = tMacWidth*3;
            mdex.height = VisHeight;
            var visCtrlDv = document.getElementById("visCtrl"); // Get the Div
            visCtrlDv.width = tMacWidth/2;
            visCtrlDv.height = CtrlHeight;
            var visModeDv = document.getElementById("visMode"); // Get the mode div
            visModeDv.width = tMacWidth/2;
            visModeDv.height = CtrlHeight;
            var visArea = document.getElementById("visuals"); // Get the canvas
            var ctxVS = visArea.getContext("2d");
            visArea.width = VisWidth;
            visArea.height = VisHeight;            
            document.addEventListener('DOMContentLoaded', function() {
                switch (MdxVisMode) {
                    case 'paddle':
                        BImNo = <?=$MdxVFBImNo?>;
                        FImNo = <?=$MdxVFFImNo?>;
                        MdxFVInit();
                        break;
                    default:
                        setImages();
                        break;
                }
            }, false);
        </script>
    <?php
    }
}

add_action ('wp_enqueue_scripts', 'mxSElements');
add_action ('wp_enqueue_scripts', 'mxVElements');
add_action('init','add_get_val');
add_action('init', 'metadex_shortcodes_init');

?>