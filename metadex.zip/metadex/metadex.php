<?php
/*
Plugin Name:   Metadex
Plugin URI:    https://github.com/giobono/metadex
Description:   Add a metadata interface to WordPress
Version:       0.6.1 (create page with post_meta, shortcode, query or post_meta settings)
Author:        Geoff Ebbs
Author URI:    http://ebono.com.au/geoff-ebbs/
*/

function add_get_val() { 
    global $wp; 
    $wp->add_query_var('MdxVisMode'); // select visualisation mode 
    $wp->add_query_var('MdxSelMode'); // select Selection mode 
    $wp->add_query_var('MdxVSelMode'); // select Selection mode 
    $wp->add_query_var('MdxContWidth'); // width of panel 
    $wp->add_query_var('MdxContHeight'); // height of panel 
    $wp->add_query_var('MdxContResponse'); // response of panel 
    $wp->add_query_var('MdxVisControls'); // select Visualisation control settings
    $wp->add_query_var('MdxVBImNo'); // Select the Background image 
    $wp->add_query_var('MdxVImBeg'); // Identify the Firstimage 
    $wp->add_query_var('MdxVImFin'); // Identify the Final image 
    $wp->add_query_var('MdxVFImNo'); // Select the image to float
    $wp->add_query_var('MdxVFPan'); // Select action on float image
    $wp->add_query_var('MdxVBLeft'); // Select Section of background image
    $wp->add_query_var('MdxVFTop'); // place float frame
    $wp->add_query_var('SavePage'); // call from jS to save page
    $wp->add_query_var('mxPMeta'); // Page meta data to be saved
    $wp->add_query_var('mxPTitle'); // Page title to be saved
}

function mxVElements() {
	wp_register_style('mdxVisualsStyle', plugins_url('metadex/elements/metadexVisuals.css', _FILE_));
	wp_enqueue_style('mdxVisualsStyle');
	wp_register_script('floatCtrl', plugins_url('metadex/elements/floatControl.js', _FILE_));
	wp_enqueue_script('floatCtrl');
	wp_register_script('float', plugins_url('metadex/elements/float.js', _FILE_));
	wp_enqueue_script('float');
}

function mxSElements() {
	wp_register_style('mdxSelectionStyle', plugins_url('metadex/elements/metadexSelection.css', _FILE_));
	wp_enqueue_style('mdxSelectionStyle');
	wp_register_script('metadex', plugins_url('metadex/elements/metadex.js', _FILE_));
	wp_enqueue_script('metadex');
}

function mxCreatePage($mdxTitle, $mdxMetadata) {
    // Create post object
    $anArray =  json_decode(stripslashes($mdxMetadata),true);
    $my_post = array(
        'post_title'    => $mdxTitle,
        'post_content'  => '[metadex]',
        'post_status'   => 'publish',
        'post_author'   => get_current_user_id(),
        'post_type'     => 'page',
        'meta_input'     => $anArray
    );

    // Insert the post into the database
    wp_insert_post( $my_post, '' );
}

function metadex_shortcodes_init() {
    add_shortcode('metadex', 'insert_metadex');
    function insert_metadex( $atts ) { 
        // Create wordpress page if required
        if (get_query_var('SavePage') ) {
            if (get_query_var('mxPTitle') && get_query_var('mxPMeta')) {
                mxCreatePage(get_query_var('mxPTitle'), get_query_var('mxPMeta'));
            } 
        }
        
// FOLLOWING SECTION TO BE REWRITTEN AS A FUNCTION with defaults and error checks
        // Process any shortcodes set by administrator
        $a = shortcode_atts( array(
            'mdxselmode' => 'off',
            'mdxvismode' => 'matrix',
            'mdxvbimno' => 1,
            'mdxvimbeg' => 1,
            'mdxvimfin' => 999999,
            'mdxvfimno' => 2,
            'mdxvfpan' => 'off',
            'mdxcontresponse' => 'on',
            'mdxcontheight' => 758,
            'mdxcontwidth' => 1024,            
            'mdxviscontrols' => 'on',
            'mdxvbleft' => '-1',
            'mdxvbtop' => '-1',
            'mdxvftop' => '500'
            ), $atts );
        $MdxVisMode = $a['mdxvismode']; // Which visualisation is selected
        $MdxSelMode = $a['mdxselmode']; // Are the selection tools visible
        $MdxVisControls = $a['mdxviscontrols']; // are the visualisation controls visible
        $MdxContWidth = $a['mdxcontwidth']; // width of panel 
        $MdxContHeight = $a['mdxcontheight']; // height of panel 
        $MdxContResponse = $a['mdxcontresponse']; // response of panel 
        $MdxVBImNo = $a['mdxvbimno']; // background image
        $MdxVImBeg = $a['mdxvimbeg']; // first image
        $MdxVImFin = $a['mdxvimfin']; // final image
        $MdxVFImNo = $a['mdxvfimno']; // floated image
        $MdxVBLeft = $a['mdxvbleft']; // edge of background image 
        $MdxVBTop = $a['mdxvbtop']; // top of background image 
        $MdxVFTop = $a['mdxvftop']; // top of floating frame  - can be overwritten in URL

        // Get settings for page from options table - Preferred method
        $MdxPageMeta = get_post_meta(get_the_ID(),'','true'); // create an array of the metadata for this post
        foreach ($MdxPageMeta as $mdxKey => $mdxValue) { // eliminate unwanted metadata and single value arrays
            $thisValue = $mdxValue[0];
            switch ($mdxKey) {
                case 'MdxVisMode':
                    $MdxVisMode = $thisValue;
                    break;
                case 'MdxSelMode':
                    $MdxSelMode = $thisValue;
                    break;
                case 'MdxVisControls':
                    $MdxVisControls = $thisValue;
                    break;
                case 'MdxContWidth':
                    $MdxContWidth = $thisValue;
                    break;
                case 'MdxContHeight':
                    $MdxContHeight = $thisValue;
                    break;
                case 'MdxContResponse':
                    $MdxContResponse = $thisValue;
                    break;
                case 'MdxVBImNo':
                    $MdxVBImNo = $thisValue;
                    break;
                case 'MdxVImBeg':
                    $MdxVImBeg = $thisValue;
                    break;
                case 'MdxVImFin':
                    $MdxVImFin = $thisValue;
                    break;
                case 'MdxVFImNo':
                    $MdxVFImNo = $thisValue;
                    break;
                case 'MdxVFPan':
                    $MdxVFPan = $thisValue;
                    break;
                case 'MdxVBLeft':
                    $MdxVBLeft = $thisValue;
                    break;
                case 'MdxVBTop':
                    $MdxVBTop = $thisValue;
                    break;
                case 'MdxVFTop':
                    $MdxVFTop = $thisValue;
                    break;
            }
        }
        
        // Override settings based on URL
        if (get_query_var('MdxVisMode') ) {
                $MdxVisMode = get_query_var('MdxVisMode');	
        }  
        if (get_query_var('MdxSelMode') ) {
                $MdxSelMode = get_query_var('MdxSelMode');	
        }  
        if (get_query_var('MdxVisControls') ) {
                $MdxVisControls = get_query_var('MdxVisControls');	
        }  
        if (get_query_var('MdxContWidth') ) {
                $MdxContWidth = get_query_var('MdxContWidth');	
        }  
        if (get_query_var('MdxContHeight') ) {
                $MdxContHeight = get_query_var('MdxContHeight');	
        }  
        if (get_query_var('MdxContResponse') ) {
                $MdxContResponse = get_query_var('MdxContResponse');	
        }  
        if (get_query_var('MdxVBImNo') ) {
                $MdxVBImNo = get_query_var('MdxVBImNo');	
        }  
        if (get_query_var('MdxVImBeg') ) {
                $MdxVImFin = get_query_var('MdxVImBeg');	
        }  
        if (get_query_var('MdxVImFin') ) {
                $MdxVImFin = get_query_var('MdxVImFin');	
        }  
        if (get_query_var('MdxVFImNo') ) {
                $MdxVFImNo = get_query_var('MdxVFImNo');	
        }  
        if (get_query_var('MdxVFPan') ) {
                $MdxVBLeft = get_query_var('MdxVFPan');	
        }  
        if (get_query_var('MdxVBLeft') ) {
                $MdxVBLeft = get_query_var('MdxVBLeft');	
        }  
        if (get_query_var('MdxVFTop') ) {
                $MdxVFTop = get_query_var('MdxVFTop');	
        }  
// END OF SECTION TO BE REWRITTEN AS A FUNCTION        
        $globs = "var MdxVisMode  = '". $MdxVisMode. "', ";
        $globs .= "MdxSelMode     = '"   . $MdxSelMode. "', ";
        $globs .= "MdxVisControls = '". $MdxVisControls. "', ";
        $globs .= "MdxContWidth   = '". $MdxContWidth. "', ";
        $globs .= "MdxContHeight  = '". $MdxContHeight. "', ";
        $globs .= "MdxContResponse= '". $MdxContResponse. "', ";
        $globs .= "MdxVBImNo = "    . $MdxVBImNo . ", ";
        $globs .= "MdxVImBeg = "    . $MdxVImBeg . ", ";
        $globs .= "MdxVImFin = "    . $MdxVImFin . ", ";
        $globs .= "MdxVFImNo = "    . $MdxVFImNo . ", ";
        $globs .= "MdxVFPan  = '"    . $MdxVFPan . "', ";
        $globs .= "MdxVBLeft = '"    . $MdxVBLeft . "', ";
        $globs .= "MdxVBTop  = '"    . $MdxVBTop . "', ";
        $globs .= "MdxVFTop  = '"    . $MdxVFTop  . "';";
        echo "<script>".$globs."</script>\n";
        $CtrlHeight = 25; // set global variable determining heifht of control bars and images
?>
        <style>:root {--CtrlHeight: <?=$CtrlHeight?>px;}</style>
        <script>
            CtrlHeight = <?=$CtrlHeight?>;
            if (Number(MdxVBLeft) > -1) MdxVBIPos[0] = Number(MdxVBLeft)/1000;
            if (Number(MdxVBTop) > -1) MdxVBIPos[1] = Number(MdxVBTop)/1000;
            if (Number(MdxVFTop) > -1) {fYTop = Number(MdxVFTop)/1000;} else {fYTop = 0.5;}
            fYBottom=fYTop+0.333;
            mdxContHeight = document.getElementById("content").clientHeight;
            mdxContWidth = document.getElementById("content").clientWidth;            
            </script>
        <div id="mdxContent">
            <div id="mdxSelection">
                <canvas id="slCtrl" onmousemove="mouse_coords(slCtrlCv, event, readTimeline)" onclick="mouse_coords(slCtrlCv, event, writeTimeline)"><p>Old browser ol' bean. Get a new one!</p></canvas>
                <div id="mdxpanels">
                    <canvas id="timeMachine" onmousemove="mouse_coords(timeMac, event, prepTimeline)" onmousedown="mouse_coords(timeMac, event, readTimeline)" onmouseup="mouse_coords(timeMac, event, writeTimeline)"><p>Old browser ol' bean. Get a new one!</p></canvas>
                    <canvas id="mdxPanel" onmousemove="mouse_coords(mdex, event, revealMdx)" onmousedown="mouse_coords(mdex, event, identifyMdx)" onmouseup="mouse_coords(mdex, event, selectMdx)"><p>Old browser ol' bean. Get a new one!</p></canvas>
                </div>
            </div>
            <div id="visZone">
                <div id="visCtrl">
                    <div id="vC1" class="vCtrl" onclick="selectCtrl(1)"></div>
                    <div id="vC2" class="vCtrl"  onclick="selectCtrl(2)"></div>
                    <div id="vC3" class="vCtrl" onclick="selectCtrl(3)"></div>
                    <div id="vC4" class="vCtrl" onclick="selectCtrl(4)"></div>	
                </div>
                <div id="visMode" >
                    <div id="vMMatrix" class="vMMode" onclick="selectMode('matrix')"><img src='/wordpress/wp-content/plugins/metadex/images/matrix.jpg' height='<?=$CtrlHeight?>' width='<?=$CtrlHeight?>' alt='Matrix' title='Display all images in a matrix'></div>
                    <div id="vMAutoplay" class="vMMode" onclick="selectMode('autoplay')"><img src='/wordpress/wp-content/plugins/metadex/images/autoplay.jpg' height='<?=$CtrlHeight?>' width='<?=$CtrlHeight?>' alt='Autoplay' title='Display images consecutively as an animation'></div>
                    <div id="vMPaddle" class="vMMode" onclick="selectMode('float')"><img src='/wordpress/wp-content/plugins/metadex/images/float.jpg' height='<?=$CtrlHeight?>' width='<?=$CtrlHeight?>' alt='float' title='Display selected images as a floating overlay'></div>
                    <div id="vMMetadex" class="vMMode" onclick="selectMode('metadex')"><img src='/wordpress/wp-content/plugins/metadex/images/metadex.jpg' height='<?=$CtrlHeight?>' width='<?=$CtrlHeight?>' alt='Metadex' title='Display stories based on content'></div>
                </div>
                <canvas id="visuals" onmousemove="mouse_coords(visArea, event, revealVis)" onmousedown="mouse_coords(visArea, event, identifyVis)" onmouseup="mouse_coords(visArea, event, selectVis)"><p>Old browser ol' bean. Get a new one!</p></canvas>
            </div>
        </div>
        <div class="hidden">
            <!-- setup content array in this hidden section to initialise javascript and canvas -->
            <img id="leftArrow" src="/wordpress/wp-content/plugins/metadex/images/lArrow.png">
            <img id="rightArrow" src="/wordpress/wp-content/plugins/metadex/images/rArrow.png">
            <img id="pauseCtrl" src="/wordpress/wp-content/plugins/metadex/images/Pause.png">
            <img id="speedCtrl" src="/wordpress/wp-content/plugins/metadex/images/Speed.png">
            <img id="moveImage" src="/wordpress/wp-content/plugins/metadex/images/moveImage.png">
            <img id="formatImage" src="/wordpress/wp-content/plugins/metadex/images/formatImage.png">
            <img id="savePage" src="/wordpress/wp-content/plugins/metadex/images/savepage.png">
            <?php // extract list of images from wordpress 
                global $wpdb;
                $sql3 = "SELECT id, post_date, post_title, guid FROM $wpdb->posts where post_type='attachment' and post_mime_type like '%image%';";
                $result3 = $wpdb->get_results( $sql3, OBJECT );
                echo "<script>var NumImages=".$wpdb->num_rows."</script>\n"; //pass global variable
                if ($wpdb->num_rows > 0) {
                    // output data of each row (converting original image name to thumbnail)
                    $imNum = 0;
                    foreach ( $result3 as $row ) {
                        $imNum = $imNum + 1;
                        echo "<img id='im".$imNum."' alt='".$row->guid."' src='".substr($row->guid,0,strrpos($row->guid,"."))."-150x150".strrchr($row->guid,".")."'>\n";
                    }
                }
            ?>
            <script>
                // replace missing thumbnails with original image
//                var img = new Image(), imgSrc;
  //              for (i = 1; i <= NumImages; i++) {
    //                imgname = "im" + i;
      //              img = document.getElementById(imgname);
        //            imgSrc = img.src;
          //          if (img.width == 0) {document.getElementById(imgname).src=imgSrc.replace("-150x150","");}
            //    }
            </script>
        </div>
        <?php if($MdxSelMode == "off") { ?>
            <style>:root {
                --VisWidPc: 100%;
                --SelDisp: none;
            }</style>
            <script>VisWidPc=1</script>
        <?php    } else { ?>
            <style>:root {
                --VisWidPc: 90%;
                --SelDisp: block;
            }</style>    
            <script>VisWidPc=0.9</script>
        <?php    } ?>
        <?php if($MdxVisControls == "off") { ?>
            <style>:root {
                --VisHeiPc: 100%;
                --CtrlDisp: none;
                --ModeDisp: none;
            }</style>
            <script>VisHeiPc=1</script>
        <?php    } else { ?>
            <style>:root {
                --VisHeiPc: 95%;
                --CtrlDisp: block;
                <?php if($MdxVisControls == "Ctrl") { ?>
                    --ModeDisp: none;
                <?php    } else { ?>
                    --ModeDisp: block;
                <?php    } ?>
            }</style>    
            <script>VisHeiPc=0.95</script>
        <?php    } ?>
        <script>
            // Global variables calculated from DOM object for placing, redrawing and reading
            // Set height and width based on Wordpress template unless unavailable or overridden
            // start with default
            var VisWidth = MdxContWidth, VisHeight=MdxContWidth;
            // override if specified
            if (MdxContWidth && MdxContHeight) {VisWidth = MdxContWidth; VisHeight = MdxContHeight;}
            // if responsive override with wordpress template (or best combination)
            if (MdxContResponse == 'on' && document.getElementById("content").offsetWidth > 0 && document.getElementById("content").offsetWidth < 9999) {
                VisHeight = Math.floor(document.getElementById("content").offsetWidth*VisHeight/VisWidth);
                VisWidth = document.getElementById("content").offsetWidth;
            }            
            // and override again if larger than screen
            if (VisHeight > 0.9 * screen.height) {
                VisWidth = Math.floor(VisWidth*0.6*screen.height/VisHeight);
                VisHeight = Math.floor(0.6*screen.height);
                document.getElementById("mdxContent").style.margin='20px';
                document.getElementById("mdxContent").style.float='left';
            }
            if (VisWidth > 0.9 * screen.width) {
                VisHeight = Math.floor(VisHeight*0.8*screen.width/VisWidth);
                VisWidth = Math.floor(0.8*screen.width);
            }
            // Now. Adjust for display requirements
            // var VisMargin = 5,
            //    VisWidth = Math.floor(document.getElementById("mdxContent").offsetWidth*VisWidPc)-2*VisMargin,
            //    VisHeight = Math.floor(document.getElementById("mdxContent").offsetHeight*.95)-2*VisMargin,
            VisWidth = Math.floor(VisWidth*VisWidPc);
            VisHeight = Math.floor(VisHeight*VisHeiPc);
            var tMacWidth = Math.floor(VisWidth/9);
            // Set up canvases for mouse activity: variables set in PHP for css and js
            // Canvases need to be sized in DOM so that images are not stretched by CSS
            var timeMac = document.getElementById("timeMachine"); // Get the canvas
            var ctxTM = timeMac.getContext("2d");
            timeMac.width = tMacWidth;
            timeMac.height = VisHeight;
            var slCtrlCv = document.getElementById("slCtrl"); // Get the canvas
            var ctxSC = slCtrlCv.getContext("2d");
            slCtrlCv.width = tMacWidth;
            slCtrlCv.height = CtrlHeight;
            var mdex = document.getElementById("mdxPanel"); // Get the canvas
            var ctxMx = mdex.getContext("2d");
            mdex.width = 0;
            mdex.height = VisHeight;
            var visCtrlDv = document.getElementById("visCtrl"); // Get the Div
            visCtrlDv.width = tMacWidth/2;
            visCtrlDv.height = CtrlHeight;
            var visModeDv = document.getElementById("visMode"); // Get the mode div
            visModeDv.width = tMacWidth/2;
            visModeDv.height = CtrlHeight;
            var visArea = document.getElementById("visuals"); // Get the canvas
            var ctxVS = visArea.getContext("2d");
            visArea.width = VisWidth;
            visArea.height = VisHeight;            
            document.addEventListener('DOMContentLoaded', function() {
                // replace missing thumbnails with original image (false load due to time out violation)
/*                var img = new Image(), imgSrc;
                for (i = 1; i <= NumImages; i++) {
                    imgname = "im" + i;
                    img = document.getElementById(imgname);
                    imgSrc = img.src;
                    console.log (imgname,img.width,imgSrc);
                    if (img.width == 0) {
                        document.getElementById(imgname).src=imgSrc.replace("-150x150","");
                        console.log ("full image ",imgSrc);
                    }
                }
*/ // replace case statement below with selectMode(MdxVisMode);
                switch (MdxVisMode) {
                    case 'float':
                        MdxVFInit();
                        break;
                    case 'autoplay':
                        console.log(MdxVBImNo);
                        ImNo = Number(MdxVBImNo);
                        if (ImNo < 1) {
                          var mousePos = [1,1];
                          ImNo = 1;
                        }
                        incIm();
                        break;
                    default:
                        setImages();
                        break;
                }
                setVCtrl(MdxVisMode);
            }, false);
        </script>
    <?php
    }
}

add_action ('wp_enqueue_scripts', 'mxSElements');
add_action ('wp_enqueue_scripts', 'mxVElements');
add_action('init','add_get_val');
add_action('init', 'metadex_shortcodes_init');

?>